#include "main.h"
#include "indicTC.h"
#include "tang.h"


// VALOR TEMPERATURA MOTOR A MOSTRAR EN EL INDICADOR.
void Indic_Temperatura(int valor_T){
    
    if (valor_T < 50) valor_T = 50;
    if (valor_T > 129) valor_T = 129;
    
    int y_offset;
    valor_T = (int)119-((valor_T - 50) * 1.5);
    
    //Escribir.
    for (y_offset=119; y_offset >= valor_T; y_offset--){  
        tft->rect( 24+tang[y_offset], y_offset+90 , 36+tang[y_offset], y_offset+90 , White );
    }

    //Borrado.
    for (y_offset = valor_T; y_offset >= 0; y_offset--){
        tft->rect( 24 + tang[y_offset] , y_offset+90 , 36+tang[y_offset], y_offset+90 , Black );
    }    

    //tft->rect( 24+tang[y_offset-1], y_offset+90-1 , 36+tang[y_offset-1], y_offset+90-1 , Black );
    //tft->rect( 24+tang[y_offset-2], y_offset+90-2 , 36+tang[y_offset-2], y_offset+90-2 , Black );
}


// VALOR COMBUSTIBLE A MOSTRAR EN EL INDICADOR.
void Indic_Combustible(int valor_C){
            
    int y_offset;
    
    //Escribir.
    for (y_offset=119; y_offset >= 119-((int)valor_C*1.19); y_offset--){     
        tft->rect( 295-tang[y_offset], y_offset+90 , 283-tang[y_offset], y_offset+90 , White );
    }

 
    //Borrado.
    for (y_offset = 119-((int)valor_C*1.19); y_offset >= 0; y_offset--){
        tft->rect( 295 - tang[y_offset] , y_offset+90 , 283-tang[y_offset], y_offset+90 , Black );
    }
    
    //tft->rect( 295-tang[y_offset-1], y_offset+90-1 , 283-tang[y_offset-1], y_offset+90-1 , Black );
    //tft->rect( 295-tang[y_offset-2], y_offset+90-2 , 283-tang[y_offset-2], y_offset+90-2 , Black );

}



// VALOR TEMPERATURA A MOSTRAR EN PRESENTACION.
void Indic_Temperatura_Present (int valor_T){
    
    //Escribir.
    tft->rect( 24+tang[valor_T], valor_T+90 , 36+tang[valor_T], valor_T+90 , White );
    
}

// VALOR COMBUSTIBLE A MOSTRAR EN PRESENTACION.
void Indic_Combustible_Present(int valor_C){
    
     //Escribir.   
    tft->rect( 295-tang[valor_C], valor_C+90 , 283-tang[valor_C], valor_C+90 , White );

}


