#include "main.h"
#include "pantalla_Aparcamiento.h"


/************************************************
    Dibujar Pantalla Aparcamiento.
*************************************************/
void Pantalla_A1() {
       
        tft->cls();
        tft->Bitmap(117,30,87,180,(unsigned char *)Imagen_vehiculo);
}

/************************************************
    Dibujar estado sensores DELANTERA       
*************************************************/

void Park_DLI(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 80 , 100+i , 50 , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 80 , 100+i , 50 , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 80 , 100+i , 50 , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 80 , 100+i , 50 , ((i*2)+10)<< 11 );  
            }           
            break;
    }            

}


void Park_DEI(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line(  100+i , 36+i , 120+i , 16+i , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line(  100+i , 36+i , 120+i , 16+i , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line(  100+i , 36+i , 120+i , 16+i , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line(  100+i , 36+i , 120+i , 16+i , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_DC(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line(  132 , 15+i , 188 , 15+i , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line(  132 , 15+i , 188 , 15+i , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line(  132 , 15+i , 188 , 15+i , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 132 , 15+i , 188 , 15+i , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_DED(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line(  220-i ,  36+i , 200-i ,  16+i , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line(  220-i ,  36+i , 200-i ,  16+i , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line(  220-i ,  36+i , 200-i ,  16+i , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 220-i ,  36+i , 200-i ,  16+i , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_DLD(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line(  220-i , 80 , 220-i , 50 ,  0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line(  220-i , 80 , 220-i , 50 , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line(  220-i , 80 , 220-i , 50 , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 220-i , 80 , 220-i , 50 , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}



/************************************************
    Dibujar estado sensores TRASERA 
*************************************************/

void Park_TLI(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 191 , 100+i , 161 , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 191 , 100+i , 161 , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 191 , 100+i , 161 , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 100+i , 191 , 100+i , 161 , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_TEI(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 120+i,  225-i  , 100+i  , 205-i  , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 120+i,  225-i  , 100+i  , 205-i  , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 120+i,  225-i  , 100+i  , 205-i  , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 120+i,  225-i  , 100+i  , 205-i  , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_TC(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 132 ,  226-i   , 188 ,  226-i , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 132 ,  226-i   , 188 ,  226-i , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 132 ,  226-i   , 188 ,  226-i , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 132 ,  226-i   , 188 ,  226-i , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_TED(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 200-i,  225-i  , 220-i  , 205-i  , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 200-i,  225-i  , 220-i  , 205-i  , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 200-i,  225-i  , 220-i  , 205-i  , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 200-i,  225-i  , 220-i  , 205-i  , ((i*2)+10)<< 11 );  
            }           
            break;
    }            
}


void Park_TLD(int color){

    switch (color) {
             
        case 0:
            for (int i=0; i<12; i++) {
                tft->line( 220-i , 191 , 220-i , 161 , 0 );  
            }
            break;
                
        case 1:
            for (int i=0; i<12; i++) {
                tft->line( 220-i , 191 , 220-i , 161 , ((i*2)+10)<< 6 );  
            }
            break;

        case 2:
            for (int i=0; i<12; i++) {
                tft->line( 220-i , 191 , 220-i , 161 , (((i*2)+10)<< 6) | (((i*2)+10)<< 11) );  
            }           
            break;
            
        case 3:
            for (int i=0; i<12; i++) {
                tft->line( 220-i , 191 , 220-i , 161 , ((i*2)+10)<< 11 );  
            }           
            break;
    }            

}



/************************************************
    Dibujar estado sensores TRAFICO CRUZADO
*************************************************/

void TrafC_Izq_ON(void){

    tft->Bitmap(62,175,30,26,(unsigned char *)Imagen_peligro);  // Aviso peligro izquierda.
}


void TrafC_Der_ON(void){

    tft->Bitmap(230,175,30,26,(unsigned char *)Imagen_peligro); // Aviso peligro derecha.
}


void TrafC_Izq_OFF(void){

    tft->fillrect(62, 175, 92, 201, Black);    // Borrado aviso peligro izquierda.
}


void TrafC_Der_OFF(void){

    tft->fillrect(230, 175, 260, 201, Black);   // Borrado aviso peligro derecha.
}





