#include "main.h"
#include "pantalla_Principal.h"
#include "tang.h"


/************************************************
    Dibujar Pantalla Principal.
*************************************************/
void Pantalla_P1() {
           
        tft->cls();
        
        // INDICADOR VELOCIDAD
        // x=140  1 cifra;  x=119 2 cifras;  x=99 3 cifras.
        tft->set_font((unsigned char*) Arial_Narrow41x76, 44, 57, false);
        tft->locate(140,35);
        tft->printf("0");
        
        tft->set_font((unsigned char*) Arial24x23);
        tft->locate(125,120);
        tft->printf("Km/h");        


        // INDICADOR TEMPERATURA        
        tft->set_font((unsigned char*) Arial15x19);
        tft->locate(5,100);
        tft->printf(" -");
        tft->locate(8,125);
        tft->printf(" -");
        tft->locate(6,150);
        tft->printf("90");
        tft->locate(12,175);
        tft->printf("70");
        tft->locate(28,200);
        tft->printf(" -");
            
        tft->Bitmap(3,200,30,25,(unsigned char *)Imagen_temp_01);    
            
        for (int b=119; b >= 30; b--){                
            tft->pixel(21 + tang[b], b+90, Orange);
            tft->pixel(22 + tang[b], b+90, Orange);
        }

        for (int b=29; b >= 0; b--){                
            tft->pixel(20 + tang[b], b+90, Red);
            tft->pixel(21 + tang[b], b+90, Red);
            tft->pixel(22 + tang[b], b+90, Red);
        }
        
        
        // INDICADOR COMBUSTIBLE
        tft->set_font((unsigned char*) Arial15x19);
        tft->locate(304,100);
        tft->printf("1");
        tft->locate(301,125);
        tft->printf("-");        
        tft->locate(291,175);
        tft->printf("-");
        tft->locate(278,200); // 281,200
        tft->printf("0");
        tft->set_font((unsigned char*) Arial12x12);
        tft->locate(297,155);  // 297,150
        tft->printf("1/2");


        tft->Bitmap(294,200,24,25,(unsigned char *)Imagen_carb_01);
        
        for (int b=119; b >= 0; b--){                
            tft->pixel(298 - tang[b], b+90, Orange);
            tft->pixel(297 - tang[b], b+90, Orange);
        }


        // DECORADOR AZUL SUPERIOR
        for (int i=0; i<15; i++)
        {
        //    tft->line(140-(i*6),  21-i,  180+(i*6),  21-i,  i*2); 
            tft->line(  0+(i*6)  ,  i  ,  319-(i*6)  ,  i  ,  31-(i*2)  ); 
        }
        tft->line (0,0,319,0,Blue);

        // DECORADOR AZUL INFERIOR
        for (int i=15; i<20; i++)
        {
            //tft->line(160-(i*6),  145+i,  160+(i*6),  145+i,  i*2); 
            tft->line(120-(i*6),  219+i,  199+(i*6),  219+i,  (i*1.5)-8); 
        }
        
        tft->line (0,239,319,239,Blue);
        
                
}
