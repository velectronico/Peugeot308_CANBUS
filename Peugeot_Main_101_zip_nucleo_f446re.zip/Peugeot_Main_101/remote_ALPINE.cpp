#include "main.h"
#include "remote_ALPINE.h"

// DEFINES
#define HIGH    1
#define LOW     0


/************************************************
    Generar pulsos control remoto ALPINE
*************************************************/ 

void writeCommand(uint16_t command) {

    // whichEnd is used to decide which end byte should be sent based on the command
    bool whichEnd = 0;

    // First write 8ms high
    remoteAlp = HIGH;
    wait_us(8000);
    
    // Send 4.5ms low
    remoteAlp = LOW;
    wait_us(4500);

    // Send the 3 command init bytes.
    // FIXME: These should be sent in reverse. See below.
    for (uint8_t i=0; i<3; i++) {

        for (uint8_t j=0; j<8; j++) {

            if (_cmdStart[i] & (1<<j)) {
                remoteAlp = HIGH;
            }
            else {
                remoteAlp = LOW;
            }
    
        wait_us(500);
        remoteAlp = LOW;
        wait_us(500);
        }
    }

    // Send the 2 command bytes. Because of the way the microprocessor stores variables,
    // we're doing it in reverse, so that the bitstream sent is the assumed one.
    for (int j=15; j>=0; j--) {

        if (command & (1<<j)) {
            remoteAlp = HIGH;
            whichEnd = 1;
        } 
        else {
            remoteAlp = LOW;
            whichEnd = 0;
        }
    
    wait_us(500);
    remoteAlp = LOW;
    wait_us(500);
    }

    // Send the end of command byte. The last bit is a checksum based on the last bit of
    // the command bytes above, but instead of changing the bit, we're having two end
    // bytes and just choose the correct one depending on the value of whichEnd.
    for (int j=7; j>=0; j--) {

        if (_cmdEnd[whichEnd] & (1<<j)) {
            remoteAlp = HIGH;
        } else {
            remoteAlp = LOW;
        }
        
    wait_us(500);
    remoteAlp = LOW;
    wait_us(500);
    }

}



/************************************************
    Control remoto radio ALPINE
*************************************************/               

void Control_ALPINE() {     
                 
    if (buffer_msg == msg_0x21F_dato0){ // Elimina falsas pulsaciones.   
        contador_iguales++;
    }
    else {
        buffer_msg = msg_0x21F_dato0;
        contador_iguales = 0;
    }
                                  
    if (contador_iguales > 1){
        contador_iguales = 0;
        pulsacion_valida = true;
    }
    else {
        pulsacion_valida = false;
    }         
                            
    if(pulsacion_valida){
            
        switch (msg_0x21F_dato0) {
                                            
            case 0x02:      // Fuente.                  // Src
                writeCommand(0xB7DB);
            break;
    
            case 0x04:      // Bajar volumen.           // Vol-
                writeCommand(0x6DF6);
            break;
            
            case 0x08:      // Subir volumen.           // Vol+
                writeCommand(0xDBD6); 
            break;
    
            case 0x0C:      // Mute.                    // Vol+ & Vol-
                writeCommand(0xADEE);
            break;
    
            case 0x40:      // Pista anterior.          // <<
                writeCommand(0x5DFA); 
            break;
    
            case 0x80:      // Pista siguiente.         // >>
                writeCommand(0xBBDA);
            break;
    
            case 0xC0:      // Conmutar a control TRIP. // << & >>
                if(can.write(CANMessage(0x3E5, CAN_msg_MENU, 6))) {
                    state_FSM_sistema = TRIP;
                }
            break;
    
            default:   // salir
    
            break;
        } // fin switch
                                           
    } // fin  if (pulsacion_valida)

} // fin void

