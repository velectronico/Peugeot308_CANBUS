
#ifndef REMOTE_ALP_H
#define REMOTE_ALP_H

#include "main.h"

void writeCommand(uint16_t command);

void Control_ALPINE(void);


#endif