
#ifndef MAIN_H
#define MAIN_H

#include "Arial12x12.h"
#include "Arial15x19.h"
#include "Arial24x23.h"
#include "Arial28x28.h"
#include "Arial43x48_numb.h"
#include "Arial43x48_numb_copy.h"
#include "Arial_Narrow41x76.h"

#include "ILI9341.h"

// IMAGENES BITMAP
#include "Imagen_Logo.h"
#include "Imagen_vehiculo.h"
#include "Imagen_carb_01.h"
#include "Imagen_carb_01_red.h"
#include "Imagen_temp_01.h"
#include "Imagen_temp_01_red.h"
#include "Imagen_interm_izq_act.h"
#include "Imagen_interm_der_act.h"
#include "Imagen_interm_desac.h"
#include "Imagen_BSD.h"
#include "Imagen_peligro.h"


extern  ILI9341*    tft;
extern  CAN         can;
extern  CANMessage  msg;
extern  CAN         can_p;
extern  CANMessage  msg_p;
extern  DigitalOut  remoteAlp; 
extern  PwmOut      backlight;
extern  PwmOut      buzzer;
extern  DigitalIn   pulsador;

// VARIABLES GENERALES
extern  bool    pulsacion_valida;   // Control mando volante.
extern  char    buffer_msg;         // Control mando volante.
extern  int     contador_iguales;   // Control mando volante.
extern  bool    combine_ON;         // Señalizar activación panel combinado.
extern  bool    contacto_ON;        // Señalizar activación contacto.
extern  bool    retroceso_ON;       // Señalizar marcha atrás.
extern  bool    pasado_PRINCIPAL_1; // Señalizar si se ha pasado alguna vexz por FMS PRINCIPAL.
                                    // Solo mostrar presentación una vez. 

// BACKUP's MSG CAN CONFORT. 
extern bool msg_0x0B6, msg_0x0F6, msg_0x128, msg_0x161, msg_0x168, msg_0x21F;

extern char msg_0x0B6_dato0, msg_0x0B6_dato1, msg_0x0B6_dato2, msg_0x0B6_dato3, msg_0x0B6_dato6;
extern char msg_0x0B6_dato0_B, msg_0x0B6_dato1_B, msg_0x0B6_dato2_B, msg_0x0B6_dato3_B,  msg_0x0B6_dato6_B;

extern char msg_0x0F6_dato0,msg_0x0F6_dato1, msg_0x0F6_dato7;
extern char msg_0x0F6_dato0_B, msg_0x0F6_dato1_B, msg_0x0F6_dato7_B;

extern char msg_0x128_dato0, msg_0x128_dato4, msg_0x128_dato5;
extern char msg_0x128_dato0_B, msg_0x128_dato4_B, msg_0x128_dato5_B;

extern char msg_0x161_dato3;
extern char msg_0x161_dato3_B;

extern char msg_0x168_dato0;
extern char msg_0x168_dato0_B;

extern char msg_0x21F_dato0, msg_0x21F_dato1;
extern char msg_0x21F_dato0_B, msg_0x21F_dato1_B;

// BACKUP's MSG CAN PARK. 
extern bool msg_p_0x001, msg_p_0x002;

extern char msg_p_0x001_dato0, msg_p_0x001_dato1, msg_p_0x001_dato2, msg_p_0x001_dato3, msg_p_0x001_dato4, msg_p_0x001_dato5, msg_p_0x001_dato6, msg_p_0x001_dato7;
extern char msg_p_0x001_dato0_B, msg_p_0x001_dato1_B, msg_p_0x001_dato2_B, msg_p_0x001_dato3_B, msg_p_0x001_dato4_B, msg_p_0x001_dato5_B, msg_p_0x001_dato6_B, msg_p_0x001_dato7_B;

extern char msg_p_0x002_dato0, msg_p_0x002_dato1, msg_p_0x002_dato2, msg_p_0x002_dato3, msg_p_0x002_dato4, msg_p_0x002_dato5, msg_p_0x002_dato6, msg_p_0x002_dato7;
extern char msg_p_0x002_dato0_B, msg_p_0x002_dato1_B, msg_p_0x002_dato2_B, msg_p_0x002_dato3_B, msg_p_0x002_dato4_B, msg_p_0x002_dato5_B, msg_p_0x002_dato6_B, msg_p_0x002_dato7_B;


// ******* MESAJES CAN ********
// Control Modo Sensores
extern  char CAN_msg_p_MR[1]; //  Modo REPOSO
extern  char CAN_msg_p_MB[1]; //  Modo BSD
extern  char CAN_msg_p_MA[1]; //  Modo APARCAMIENTO


// Estados sistema.
typedef enum {REPOSO, PRESENTACION, PRINCIPAL_1, PRINCIPAL_2, APARCAMIENTO, CIERRE} state_sistem;
extern  state_sistem  state_FSM_sistem;

// Estados control mando volante.
typedef enum {TRIP, ALPINE} state_sistema;
extern state_sistema  state_FSM_sistema;


// Mensages Tx CAN
extern char CAN_msg_Reposo[6];
extern char CAN_msg_Derecha[6];
extern char CAN_msg_Izquierda[6];
extern char CAN_msg_MENU[6];
extern char CAN_msg_ESC[6];
extern char CAN_msg_Arriba[6];
extern char CAN_msg_Abajo[6];
extern char CAN_msg_OK[6];


extern  const uint8_t  _cmdStart[3];
extern  const uint8_t  _cmdEnd[2];


#endif