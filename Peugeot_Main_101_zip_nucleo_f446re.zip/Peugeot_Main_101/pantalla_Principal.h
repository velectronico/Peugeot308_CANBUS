
#ifndef PANTALLA_P1_H
#define PANTALLA_P1_H

#include "main.h"

void Pantalla_P1(void);


#endif