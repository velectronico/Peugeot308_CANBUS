
#include "main.h"
#include "mantenimiento.h"


/************************************************
    MANTENIMIENTO
*************************************************/  
void Mantenimiento()
{
    int id=0;
    backlight.write(1);
    
    tft->set_font((unsigned char*) Arial15x19);
                      
    can_p.write(CANMessage(0x003, CAN_msg_p_MA, 1));   // Activar: Modo Parking sensores.
  
    while (true){
        
        if (!pulsador) {           
            wait(0.4);
            id++;
            if (id >= 8) id=0;
        }
        
        if (msg_0x0B6 && (id==0)) {
            msg_0x0B6 = false;
            tft->locate(0,20);
            tft->printf("0B6 %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }
        
        if (msg_0x0F6 && (id==1)) {
            msg_0x0F6 = false;
            tft->locate(0,40);
            tft->printf("0F6 %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }
 
        if (msg_0x128 && (id==2)) {
            msg_0x128 = false;
            tft->locate(0,60);
            tft->printf("128 %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }
        if (msg_0x161 && (id==3)) {
            msg_0x161 = false;
            tft->locate(0,80);
            tft->printf("161 %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }
        if (msg_0x168 && (id==4)) {
            msg_0x168 = false;
            tft->locate(0,100);
            tft->printf("168 %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }

        if (msg_0x21F && (id==5)) {
            msg_0x21F = false;
            tft->locate(0,120);
            tft->printf("21F %d %d %d %d %d %d %d %d   ", msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
        }


        
        if (msg_p_0x001 && (id==6)) {
            msg_p_0x001 = false;
            tft->locate(0,140);
            tft->printf("001 %d %d %d %d %d %d %d %d   ", msg_p.data[0], msg_p.data[1], msg_p.data[2], msg_p.data[3], msg_p.data[4], msg_p.data[5], msg_p.data[6], msg_p.data[7]);
        }

        if (msg_p_0x002 && (id==7)) {
            msg_p_0x002 = false;
            tft->locate(0,160);
            tft->printf("002 %d %d %d %d %d %d %d %d   ", msg_p.data[0], msg_p.data[1], msg_p.data[2], msg_p.data[3], msg_p.data[4], msg_p.data[5], msg_p.data[6], msg_p.data[7]);
        }



            
    }    
}
