#include "main.h"
#include "controlTRIP.h"


/**************************************************************************************
    CONTROL PANTALLA TRIP
***************************************************************************************

      Mando Volante                       Convertidos
Reposo      21F 00 00 00        Reposo      3E5 00 00 00 00 00 00
>>          21F 80 00 00        Derecha     3E5 00 00 00 00 00 04
<<          21F 40 00 00        Izquierda   3E5 00 00 00 00 00 01
Vol+        21F 08 00 00        MENU        3E5 40 00 00 00 00 00
Vol-        21F 04 00 00        ESC         3E5 00 00 10 00 00 00
Memo (sub.) 21F 00 xx 00        Arriba      3E5 00 00 00 00 00 40
Memo (baj.) 21F 00 xx 00        Abajo       3E5 00 00 00 00 00 10
Src         21F 02 00 00        OK          3E5 00 00 40 00 00 00

***************************************************************************************/              
void Control_TRIP() {

    if (msg_0x21F_dato1 > msg_0x21F_dato1_B){   // Control rueda MEMO.
        msg_0x21F_dato1_B = msg_0x21F_dato1;
        msg_0x21F_dato0 = 0x01;               // Gestionar si se mueve "Arriba".
    }

    if (msg_0x21F_dato1 < msg_0x21F_dato1_B){   // Control rueda MEMO.
        msg_0x21F_dato1_B = msg_0x21F_dato1;
        msg_0x21F_dato0 = 0x10;               // Gestionar si se mueve "Abajo".
    }
                    
    switch (msg_0x21F_dato0) {
                                               
        case 0x01:      // Rueda MEMO Arriba    -->     Arriba
            can.write(CANMessage(0x3E5, CAN_msg_Arriba, 6));
        break;
                    
        case 0x10:      // Rueda MEMO Abajo     -->     Abajo
            can.write(CANMessage(0x3E5, CAN_msg_Abajo, 6));
        break;  
               
        case 0x02:      // Src      -->     OK
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_OK, 6));
        break;
    
        case 0x04:      // Vol-     -->     ESC
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_ESC, 6));
            state_FSM_sistema = ALPINE;
            //to_regreso_control_ALPINE.attach(&conmuta_control_ALPINE, 5); // Regresa al control de la radio ALPINE en 5sg.             
        break;
            
        case 0x08:      // Vol+     -->     MENU
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_MENU, 6));
            //to_regreso_control_ALPINE.detach();                 
        break;
    
        case 0x40:      // <<       -->     Izquierda
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_Izquierda, 6));                    
        break;
    
        case 0x80:      // >>       -->     Derecha
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_Derecha, 6));                    
        break;
    
        default:        // Reposo   -->     Reposo
            msg_0x21F_dato0 = 0;
            can.write(CANMessage(0x3E5, CAN_msg_Reposo, 6));
        break;
    } // fin switch
        
} // fin void

