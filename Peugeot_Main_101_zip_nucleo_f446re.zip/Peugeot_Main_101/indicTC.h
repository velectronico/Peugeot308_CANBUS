
#ifndef INDICTC_H
#define INDICTC_H


#include "main.h"

// VALOR TEMPERATURA MOTOR A MOSTRAR EN EL INDICADOR.
void Indic_Temperatura(int valor_T);

// VALOR COMBUSTIBLE A MOSTRAR EN EL INDICADOR.
void Indic_Combustible(int valor_C);

// VALOR TEMPERATURA A MOSTRAR EN PRESENTACION.
void Indic_Temperatura_Present (int valor_T);

// VALOR COMBUSTIBLE A MOSTRAR EN PRESENTACION.
void Indic_Combustible_Present(int valor_C);


#endif