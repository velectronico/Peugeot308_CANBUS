#include "mbed.h"
#include "ILI9341.h"
#include "main.h"
#include "tang.h"
#include "indicTC.h"
#include "controlTRIP.h"
#include "remote_ALPINE.h"
#include "mantenimiento.h"
#include "pantalla_Principal.h"
#include "pantalla_Aparcamiento.h"
#include "buzzer.h"

//Serial pc(USBTX, USBRX); // tx, rx

// CONFIGURACION
ILI9341*    tft;                        // ILI9341 driver.
DigitalOut  led (PA_5);                 // PA_5
DigitalIn   pulsador (PC_13);           // PC_13

//DigitalOut  ledd (PC_8);
PwmOut      backlight (PC_8);           // Retroiluminación pantalla.
PwmOut      buzzer (PB_0);              // Buzzer, Beep.

//CAN CONFORT
CAN         can(PB_8, PB_9, 125000);    // RD, TD, speed.
CANMessage  msg;                        // Mensages rx.
//CAN PARK
CAN         can_p(PB_12, PB_6, 125000);  // RD, TD, speed. 20K
CANMessage  msg_p;                      // Mensages rx.


Timeout     to_regreso_control_ALPINE;
Timeout     BSD_intermitente_izq;       //Tiempo que permanece la señalizacion BSD despues de ser detectado.
Timeout     BSD_intermitente_der;       //Tiempo que permanece la señalizacion BSD despues de ser detectado.
Timeout     Traf_Cruzado;                //Tiempo operativo detector de Trafico Cruzado.
DigitalOut  remoteAlp(PA_8);            // Salida control remoto Alpine.
Ticker      tic_rate_velocidad;         // Refresco valor velocidad en display.
Ticker      Sound_2;


// VARIABLES GENERALES
bool    pulsacion_valida = false;       // Control mando volante.
char    buffer_msg = {0x00};            // Control mando volante.
int     contador_iguales = 0;           // Control mando volante.
unsigned short rpm, velocidad;
bool    rate_velocidad = false;         // Refrescar valor velocidad en display.
bool    combine_ON = false;             // Señalizar activación panel combinado.
bool    contacto_ON = false;            // Señalizar activación contacto.
bool    retroceso_ON = false;           // Activado marcha atrás.
bool    izquierda_ON = false;           // Activado intermitente izquierdo.
bool    derecha_ON = false;             // Activado intermitente derecho.
bool    pasado_PRINCIPAL_1 = false;     // Señalizar si se ha pasado alguna vexz por FMS PRINCIPAL.
                                        // Solo mostrar presentación una vez.
bool    activo_BSD = false;             // Sistema BSD activo.

bool    BSD_izq_Alarm_Imagen = false;   // Presentar imagen de alarma izquierda.
bool    BSD_der_Alarm_Imagen = false;   // Presentar imagen de alarma derecha.
bool    BSD_izq_NoAlarm_Imagen = false; // Borrar imagen de alarma izquierda.
bool    BSD_der_NoAlarm_Imagen = false; // Borrar imagen de alarma derecha.
bool    BSD_izq_Alarm_Imagen_F = false; // Flag Presentar imagen de alarma izquierda. (Solo pinta una vez).
bool    BSD_der_Alarm_Imagen_F = false; // Flag Presentar imagen de alarma derecha. (Solo pinta una vez).
bool    BSD_izq_NoAlarm_Imagen_F = false; // Flag Borrar imagen de alarma izquierda. (Solo pinta una vez).
bool    BSD_der_NoAlarm_Imagen_F = false; // Flag Borrar imagen de alarma derecha. (Solo pinta una vez).

bool    Detector_Traf_Cruzado = true;   // Detectores de Trafico Cruzado preparados para su uso.

float   Max_backlight=65;               // Brillo maximo backlight.
float   Min_backlight=10;               // Brillo minimo backlight.

// SONIDO
char    Park_Sound[10];                 // Registro tipo de sonido por sensor.  0:DLI   1:DEI   2:DC    3:DED   4:DLD
                                        //                                      5:TLI   6:TEI   7:TC    8:TED   9:TLD
char    Park_Sound_Play;                // Sonido final a reproducir.
char    Park_Sound_Play_B;              // Sonido final a reproducir backup.

// BACKUP's MSG CAN CONFORT. 
bool msg_0x0B6 = 0, msg_0x0F6 = 0, msg_0x128 = 0, msg_0x161 = 0, msg_0x168 = 0, msg_0x21F = 0;

char msg_0x0B6_dato0, msg_0x0B6_dato1, msg_0x0B6_dato2, msg_0x0B6_dato3, msg_0x0B6_dato6;
char msg_0x0B6_dato0_B, msg_0x0B6_dato1_B, msg_0x0B6_dato2_B, msg_0x0B6_dato3_B,  msg_0x0B6_dato6_B;

char msg_0x0F6_dato0,msg_0x0F6_dato1, msg_0x0F6_dato7;
char msg_0x0F6_dato0_B, msg_0x0F6_dato1_B, msg_0x0F6_dato7_B;

char msg_0x128_dato0, msg_0x128_dato4, msg_0x128_dato5;
char msg_0x128_dato0_B, msg_0x128_dato4_B, msg_0x128_dato5_B;

char msg_0x161_dato3;
char msg_0x161_dato3_B;

char msg_0x168_dato0;
char msg_0x168_dato0_B;

char msg_0x21F_dato0, msg_0x21F_dato1;
char msg_0x21F_dato0_B, msg_0x21F_dato1_B = 0;


// BACKUP's MSG CAN PARK. 
bool msg_p_0x001 = 0, msg_p_0x002 = 0;

char msg_p_0x001_dato0, msg_p_0x001_dato1, msg_p_0x001_dato2, msg_p_0x001_dato3, msg_p_0x001_dato4, msg_p_0x001_dato5, msg_p_0x001_dato6, msg_p_0x001_dato7;
char msg_p_0x001_dato0_B, msg_p_0x001_dato1_B, msg_p_0x001_dato2_B, msg_p_0x001_dato3_B, msg_p_0x001_dato4_B, msg_p_0x001_dato5_B, msg_p_0x001_dato6_B, msg_p_0x001_dato7_B;

char msg_p_0x002_dato0, msg_p_0x002_dato1, msg_p_0x002_dato2, msg_p_0x002_dato3, msg_p_0x002_dato4, msg_p_0x002_dato5, msg_p_0x002_dato6, msg_p_0x002_dato7;
char msg_p_0x002_dato0_B, msg_p_0x002_dato1_B, msg_p_0x002_dato2_B, msg_p_0x002_dato3_B, msg_p_0x002_dato4_B, msg_p_0x002_dato5_B, msg_p_0x002_dato6_B, msg_p_0x002_dato7_B;



// FILTRO VALORES MEDIDAS PARK.
char Cont_Msg_DLI0, Cont_Msg_DLI1, Cont_Msg_DLI2, Cont_Msg_DLI3, Cont_Msg_DLI4;
char Cont_Msg_DEI0, Cont_Msg_DEI1, Cont_Msg_DEI2, Cont_Msg_DEI3;
char Cont_Msg_DC0, Cont_Msg_DC1, Cont_Msg_DC2, Cont_Msg_DC3;
char Cont_Msg_DLD0, Cont_Msg_DLD1, Cont_Msg_DLD2, Cont_Msg_DLD3, Cont_Msg_DLD4;
char Cont_Msg_DED0, Cont_Msg_DED1, Cont_Msg_DED2, Cont_Msg_DED3;

char Cont_Msg_TLI0, Cont_Msg_TLI1, Cont_Msg_TLI2, Cont_Msg_TLI3, Cont_Msg_TLI4;
char Cont_Msg_TEI0, Cont_Msg_TEI1, Cont_Msg_TEI2, Cont_Msg_TEI3;
char Cont_Msg_TC0, Cont_Msg_TC1, Cont_Msg_TC2, Cont_Msg_TC3;
char Cont_Msg_TLD0, Cont_Msg_TLD1, Cont_Msg_TLD2, Cont_Msg_TLD3, Cont_Msg_TLD4;
char Cont_Msg_TED0, Cont_Msg_TED1, Cont_Msg_TED2, Cont_Msg_TED3;



// ******* MESAJES CAN ********
// Control Modo Sensores
char CAN_msg_p_MR [1] = {0x00}; //  Modo REPOSO
char CAN_msg_p_MB [1] = {0x01}; //  Modo BSD
char CAN_msg_p_MA [1] = {0x02}; //  Modo APARCAMIENTO

// Control TRIP
char CAN_msg_Reposo[6] =    {0x00,0x00,0x00,0x00,0x00,0x00};
char CAN_msg_Derecha[6] =   {0x00,0x00,0x00,0x00,0x00,0x04};
char CAN_msg_Izquierda[6] = {0x00,0x00,0x00,0x00,0x00,0x01};
char CAN_msg_MENU[6] =      {0x40,0x00,0x00,0x00,0x00,0x00};
char CAN_msg_ESC[6] =       {0x00,0x00,0x10,0x00,0x00,0x00};
char CAN_msg_Arriba[6] =    {0x00,0x00,0x00,0x00,0x00,0x40};
char CAN_msg_Abajo[6] =     {0x00,0x00,0x00,0x00,0x00,0x10};
char CAN_msg_OK[6] =        {0x00,0x00,0x40,0x00,0x00,0x00};
// ****************************

// Control remoto ALPINE (string _bitstream).
const uint8_t  _cmdStart[3] =  {0xeb, 0xdb, 0xd5};
const uint8_t  _cmdEnd[2] =    {0xD5, 0x55};

// Estados sistema.
//typedef enum {REPOSO, PRESENTACION, PRINCIPAL_1, PRINCIPAL_2, APARCAMIENTO, CIERRE} state_sistem;
state_sistem  state_FSM_sistem = REPOSO;

// Estados control mando volante.
//typedef enum {TRIP, ALPINE} state_sistema;
state_sistema  state_FSM_sistema = ALPINE;

// METODOS
void met_rate_velocidad() { rate_velocidad = true;}      // Refrescar velocidad.


void Sound_2_Beep()
{
    Beep(0.1);
}

// Borrar señalizacion obstaculo izquierda.
void BSD_izq_OFF() {
    BSD_izq_NoAlarm_Imagen = true;
}

// Borrar señalizacion obstaculo derecho.
void BSD_der_OFF() {
    BSD_der_NoAlarm_Imagen = true;
}

// Desactiva la deteccion del trafico cruzado.
void Traf_Cruzado_OFF(){
    Detector_Traf_Cruzado= false;
}


/************************************************
    Gestion interrupciones Rx CAN CONFORT
*************************************************/  
void can_irq() {
        

//__disable_irq();    // Disable Interrupts

    
    if (can.read(msg)) {
        
        if(msg.id == 0x0B6){
            msg_0x0B6 = true;
            msg_0x0B6_dato0 = msg.data[0];
            msg_0x0B6_dato1 = msg.data[1];
            msg_0x0B6_dato2 = msg.data[2];
            msg_0x0B6_dato3 = msg.data[3];
            msg_0x0B6_dato6 = msg.data[6];
        }
            
        if(msg.id == 0x0F6){
            msg_0x0F6 = true;
            msg_0x0F6_dato0 = msg.data[0];
            msg_0x0F6_dato1 = msg.data[1];
            msg_0x0F6_dato7 = msg.data[7];
        }
        
        if(msg.id == 0x128){
            msg_0x128 = true;
            msg_0x128_dato0 = msg.data[0];
            msg_0x128_dato4 = msg.data[4];
            msg_0x128_dato5 = msg.data[5];
        }       
        
        if(msg.id == 0x161){
            msg_0x161 = true;
            msg_0x161_dato3 = msg.data[3];
        }
        
        if(msg.id == 0x168){
            msg_0x168 = true;
            msg_0x168_dato0 = msg.data[0];
        }
        
        if(msg.id == 0x21F){
            msg_0x21F = true;
            msg_0x21F_dato0 = msg.data[0];
            msg_0x21F_dato1 = msg.data[1];         
        }      
        
    }
    
//__enable_irq();     // Enable Interrupts
}


/************************************************
    Gestion interrupciones Rx CAN PARK
*************************************************/  
void can_p_irq() {

//__disable_irq();    // Disable Interrupts    

    if (can_p.read(msg_p)) {

        if(msg_p.id == 0x001){
            msg_p_0x001 = true;
            msg_p_0x001_dato0 = msg_p.data[0];
            msg_p_0x001_dato1 = msg_p.data[1];
            msg_p_0x001_dato2 = msg_p.data[2];
            msg_p_0x001_dato3 = msg_p.data[3];
            msg_p_0x001_dato4 = msg_p.data[4];
            msg_p_0x001_dato5 = msg_p.data[5];
            msg_p_0x001_dato6 = msg_p.data[6];
            msg_p_0x001_dato7 = msg_p.data[7];
        }
            
        if(msg_p.id == 0x002){
            msg_p_0x002 = true;
            msg_p_0x002_dato0 = msg_p.data[0];
            msg_p_0x002_dato1 = msg_p.data[1];
            msg_p_0x002_dato2 = msg_p.data[2];
            msg_p_0x002_dato3 = msg_p.data[3];
            msg_p_0x002_dato4 = msg_p.data[4];
            msg_p_0x002_dato5 = msg_p.data[5];
            msg_p_0x002_dato6 = msg_p.data[6];
            msg_p_0x002_dato7 = msg_p.data[7];
        }
    }
    
//__enable_irq();     // Enable Interrupts
}



/**************************************************************************************
    Gestión mensajes Rx CAN CONFORT
***************************************************************************************

0B6 (0)MMMMMMMM (1)MMMMM000     (M)Tachometer: turns per minute of motor
    (2)SSSSSSSS (3)SSSSSSSS     (S)Actual speed * 100 in km/h
 
0F6 (0)0000X000             (X) Ignition
    (1)CCCCCCCC             (C) Coolant Temperature = C-39 °C
    (6)R00000ZF             (R) Reverse gear light
                            (Z) Turn left light
                            (F) Turn right light

128 (0)000F0000             (F) Fuel empty
    (4)G0000ID0             (G) Sidelights on
                            (I) Turn left ind. combine.
                            (D) Turn right ind. combine.
    (5)B0000000             (B) Combine ON/OFF

161 (3)NNNNNNNN             (N) Fuel level

168 (0)J0000000             (J) Coolant hight temperature.

21F (0)FBX0UDS0             (F) Forward
                            (B) Backward
                            (U) Volume up
                            (D) Volume down
                            (S) Source
    (1)RRRRRRRR             (R) Scroll value. Continuously values.

***************************************************************************************/
void Gestion_msg()
{
     
//----------------------------------------------//
    if (msg_0x0B6) {

        msg_0x0B6 = 0;
            
        // Mostrar velocidad.
        if ( ( ((msg_0x0B6_dato2_B != msg_0x0B6_dato2) || (msg_0x0B6_dato3_B != msg_0x0B6_dato3)) && rate_velocidad  ) && (state_FSM_sistem == PRINCIPAL_2) ){

            rate_velocidad = false;                 // Esperar nuevo refresco valor velocidad.
            msg_0x0B6_dato2_B = msg_0x0B6_dato2;    // Guardar nuevos valores velocidad.
            msg_0x0B6_dato3_B = msg_0x0B6_dato3;    // Guardar nuevos valores velocidad.
                
            velocidad = ((((msg_0x0B6_dato2 << 8) + msg_0x0B6_dato3) / 100)); //                                 
                
            tft->set_font((unsigned char*) Arial_Narrow41x76, 44, 57, false);
            
            if (velocidad < 10){
                tft->locate(99,35);
                tft->printf(" %d ", velocidad);}
            else if ((velocidad > 9) && (velocidad <100)){
                tft->locate(78,35);
                tft->printf(" %d ", velocidad);}
            else {
                tft->locate(99,35);
                tft->printf("%d", velocidad);}
        }
    }
//----------------------------------------------//


//----------------------------------------------//
    if (msg_0x0F6) {
            
        msg_0x0F6 = 0;
            
        // Mostrar:  data[0] 0000i000    i: ignición 0-> OFF   1-> ON
        //if (msg_0x0F6_dato0_B != msg_0x0F6_dato0) {
                
            //msg_0x0F6_dato0_B = msg_0x0F6_dato0;
                
            if (msg_0x0F6_dato0 & 0x08)
                contacto_ON = true;
            else
                contacto_ON = false;
         //   }


        // Mostrar:  data[7] R00000ID    R: Retroceder;  I: Intermitente Izquierdo;  D: Intermitente Derecho.
        if (msg_0x0F6_dato7_B != msg_0x0F6_dato7) {
                
            msg_0x0F6_dato7_B = msg_0x0F6_dato7;
                
            
            if (msg_0x0F6_dato7 & 0x80)
                retroceso_ON = true;        // Marcha atrás.
            else
                retroceso_ON = false;       // Marcha adelante.
            
            
            if (msg_0x0F6_dato7 & 0x02)
                izquierda_ON = true;        // Activado intermitente izquierdo.
            else
                izquierda_ON = false;       // Desactivado intermitente izquierdo.
                    

            if (msg_0x0F6_dato7 & 0x01) 
                derecha_ON = true;          // Activado intermitente derecho.
            else
                derecha_ON = false;         // Desactivado intermitente derecho.
        }


            
        // Mostrar temperatura refrigerante. Solo en estado FSM: PRINCIPAL.
        if ( (msg_0x0F6_dato1_B != msg_0x0F6_dato1) && (state_FSM_sistem == PRINCIPAL_2) ) {
            
            msg_0x0F6_dato1_B = msg_0x0F6_dato1;

            tft->set_font((unsigned char*) Arial15x19);
            tft->locate(35,215);
            tft->printf(" %d^ ", (msg_0x0F6_dato1 - 39)); // caracter ^ sustituido por º.
            
            Indic_Temperatura (msg_0x0F6_dato1 - 39);    // Valor temperatura a mostrar en el indicador.
        }                                                          

    }
//----------------------------------------------//


//----------------------------------------------//            
    if (msg_0x128) {
            
        msg_0x128 = 0;
            
        // Mostrar indicacion reserva.
        if ( (msg_0x128_dato0_B != msg_0x128_dato0) && (state_FSM_sistem == PRINCIPAL_2) ){
                
            msg_0x128_dato0_B = msg_0x128_dato0;
                
            if (msg_0x128_dato0 & 0x10)
                tft->Bitmap(293,200,24,25,(unsigned char *)Imagen_carb_01_red);
            else
                tft->Bitmap(293,200,24,25,(unsigned char *)Imagen_carb_01);
        }

            
        // Luces de posición. Ajuste luz backlight.
        if (  (msg_0x128_dato4_B != msg_0x128_dato4)  && ( (state_FSM_sistem == PRESENTACION) || (state_FSM_sistem == PRINCIPAL_1) || (state_FSM_sistem == PRINCIPAL_2) || (state_FSM_sistem == APARCAMIENTO) ) ) {
                
            float   f_backlight;
            
            msg_0x128_dato4_B = msg_0x128_dato4;

            if (msg_0x128_dato4 & 0x80)
                f_backlight = Min_backlight/100;  // 10% duty cycle
            else
                f_backlight = Max_backlight/100;  // 10% duty cycle
            
            backlight.write(f_backlight);
            
            
            // Indicador intermitente IZQUIERDO.
            if (msg_0x128_dato4 & 0x02)
                tft->Bitmap(10,20,42,45,(unsigned char *)Imagen_interm_izq_act);
            else
                tft->Bitmap(10,20,42,45,(unsigned char *)Imagen_interm_desac);
            
            // Indicador intermitente DERECHO.
            if (msg_0x128_dato4 & 0x04)
                tft->Bitmap(268,20,42,45,(unsigned char *)Imagen_interm_der_act);
            else
                tft->Bitmap(268,20,42,45,(unsigned char *)Imagen_interm_desac);
                                  
       }
                      
  
        // 'COMBINE ON/OFF'
        if (msg_0x128_dato5_B != msg_0x128_dato5) {
                
            msg_0x128_dato5_B = msg_0x128_dato5;
                            
            if (msg_0x128_dato5 & 0x80)
                combine_ON = true;
            else
                combine_ON = false;
                
        }
    }
//----------------------------------------------//


//----------------------------------------------//      
    if (msg_0x161) {
            
        msg_0x161 = 0;
            
        // Mostrar nivel de combustible.
        if ( (msg_0x161_dato3_B != msg_0x161_dato3) && (state_FSM_sistem == PRINCIPAL_2)  ){
                
            msg_0x161_dato3_B = msg_0x161_dato3;
                
            tft->set_font((unsigned char*) Arial15x19);
            tft->locate(248,215);
            tft->printf("%dL ", (int)msg_0x161_dato3/2);

            Indic_Combustible (msg_0x161_dato3);    // Valor combustible a mostrar en el indicador.
        }
    }
//----------------------------------------------//


//----------------------------------------------//
    if (msg_0x168) {
            
        msg_0x168 = 0;
            
        // Mostrar alarma sobretemperatura refrigerante.
        if ( (msg_0x168_dato0_B != msg_0x168_dato0) && (state_FSM_sistem == PRINCIPAL_2) ){
                
            msg_0x168_dato0_B = msg_0x168_dato0;

            if (msg_0x168_dato0 & 0x80)
                tft->Bitmap(3,200,30,25,(unsigned char *)Imagen_temp_01_red);
            else
                tft->Bitmap(3,200,30,25,(unsigned char *)Imagen_temp_01);
        }
    }
//----------------------------------------------//


//----------------------------------------------//
    if (msg_0x21F) {
            
        msg_0x21F = 0;
          
        // Gestion control mando volante.
        switch (state_FSM_sistema) {
                
            case TRIP:      //  Gestion pantalla TRIP.
                Control_TRIP();
            break;

            default:        //  Gestion radio ALPINE
               Control_ALPINE();
        }
    }
//----------------------------------------------//

} 


/**************************************************************************************
    Gestión mensajes Rx CAN PARK
***************************************************************************************

Transmisión:
    ID 003
        (0)0xMM     MM=00   Modo    Reposo
                    MM=01   Modo    BSD
                    MM=02   Modo    Parking


Recepción:  Dato * 2 = cm
    ID 001 (Modo Parking) Sensores delanteros.
        (0)0xDD     Delantero    Lateral    Izquierdo.  (0...500 cm)
        (1)0xDD     Delantero    Esquina    Izquierdo.  (0...500 cm)
        (2)0xDD     Delantero    Central    Izquierdo.  (0...500 cm)
        (3)0xDD     Delantero    Central    Derecho.    (0...500 cm)
        (4)0xDD     Delantero    Esquina    Derecho.    (0...500 cm)
        (5)0xDD     Delantero    Lateral    Derecho.    (0...500 cm)
        (6)0xDD
        (7)0xDD
    
    ID 002 (Modo Parking) Sensores traseros.
        (0)0xTT     Trasero     Lateral     Izquierdo.  (0...500 cm)
        (1)0xTT     Trasero     Esquina     Izquierdo.  (0...500 cm)
        (2)0xTT     Trasero     Central     Izquierdo.  (0...500 cm)
        (3)0xTT     Trasero     Central     Derecho.    (0...500 cm)
        (4)0xTT     Trasero     Esquina     Derecho.    (0...500 cm)
        (5)0xTT     Trasero     Lateral     Derecho.    (0...500 cm)
        (6)0xTT
        (7)0xTT

    ID 002 (Modo BSD) Sensores traseros
        (0)0xTT     Trasero     Lateral     Izquierdo.  (0...500 cm)
        (1)0xTT     
        (2)0xTT     
        (3)0xTT     
        (4)0xTT     
        (5)0xTT     Trasero     Lateral     Derecho.    (0...500 cm)
        (6)0xTT
        (7)0xTT

***************************************************************************************/
void Gestion_msg_p()
{
     
//----------------------------------------------//
//  Mensajes sensores delanteros.
//----------------------------------------------//
    
    if (msg_p_0x001) {
            
        msg_p_0x001 = false;
        
        if ( (msg_p_0x001_dato0 != msg_p_0x001_dato0_B) || (msg_p_0x001_dato1 != msg_p_0x001_dato1_B) || (msg_p_0x001_dato2 != msg_p_0x001_dato2_B) || 
                (msg_p_0x001_dato3 != msg_p_0x001_dato3_B) || (msg_p_0x001_dato4 != msg_p_0x001_dato4_B) || (msg_p_0x001_dato5 != msg_p_0x001_dato5_B)  )  {
                
            msg_p_0x001_dato0_B = msg_p_0x001_dato0;
            msg_p_0x001_dato1_B = msg_p_0x001_dato1;
            msg_p_0x001_dato2_B = msg_p_0x001_dato2;
            msg_p_0x001_dato3_B = msg_p_0x001_dato3;
            msg_p_0x001_dato4_B = msg_p_0x001_dato4;
            msg_p_0x001_dato5_B = msg_p_0x001_dato5;
             
            /*            
            tft->set_font((unsigned char*) Arial15x19);
            tft->locate(20,90);
            tft->printf(" %d %d    %d %d    %d %d ", (int)msg_p_0x001_dato0 * 2, (int)msg_p_0x001_dato1 * 2, (int)msg_p_0x001_dato2 * 2, (int)msg_p_0x001_dato3 * 2, (int)msg_p_0x001_dato4 * 2, (int)msg_p_0x001_dato5 * 2);
            */
            
            //*********************************************
            //  Mostrar estado en pantalla:
            //     0 ... 255              0cm ... 500cm
            //            
            //  0...    12      >>      0cm...      24cm    Rojo
            //  13...   25      >>      >28cm...    50cm    Amarillo.
            //  26...   50      >>      >84cm...    100cm   Verde.
            //  >100cm          No mostrar.
            //            
            //  Numeracion sensores:
            //    0:DLI   1:DEI   2:DC    3:DED   4:DLD
            //*********************************************

            // Gestion DLI
            switch (msg_p_0x001_dato0_B) {               

                case 0 ... 12:
                    Cont_Msg_DLI3++;
                    if (Cont_Msg_DLI3 >= 3){                    
                        Park_DLI(3);
                        Park_Sound[0] = 3;
                        Cont_Msg_DLI3=2;
                        Cont_Msg_DLI2=0;
                        Cont_Msg_DLI1=0;
                        Cont_Msg_DLI0=0;
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_DLI2++;
                    if (Cont_Msg_DLI2 >= 3){                    
                        Park_DLI(2);
                        Park_Sound[0] = 2;
                        Cont_Msg_DLI3=0;
                        Cont_Msg_DLI2=2;
                        Cont_Msg_DLI1=0;
                        Cont_Msg_DLI0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_DLI1++;
                    if (Cont_Msg_DLI1 >= 3){   
                        Park_DLI(1);
                        Park_Sound[0] = 1;
                        Cont_Msg_DLI3=0;
                        Cont_Msg_DLI2=0;
                        Cont_Msg_DLI1=2;
                        Cont_Msg_DLI0=0;
                    }    
                break;
            
    
                default:
                    Cont_Msg_DLI0++;
                    if (Cont_Msg_DLI0 >= 3){
                        Park_DLI(0);
                        Park_Sound[0] = 0;
                        Cont_Msg_DLI3=0;
                        Cont_Msg_DLI2=0;
                        Cont_Msg_DLI1=0;
                        Cont_Msg_DLI0=2;
                    }
                break;
            }



            // Gestion DEI
            switch (msg_p_0x001_dato1_B) {
                
                case 0 ... 12:
                    Cont_Msg_DEI3++;
                    if (Cont_Msg_DEI3 >= 3){                    
                        Park_DEI(3);
                        Park_Sound[1] = 3;
                        Cont_Msg_DEI3=2;
                        Cont_Msg_DEI2=0;
                        Cont_Msg_DEI1=0;
                        Cont_Msg_DEI0=0;
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_DEI2++;
                    if (Cont_Msg_DEI2 >= 3){                    
                        Park_DEI(2);
                        Park_Sound[1] = 2;
                        Cont_Msg_DEI3=0;
                        Cont_Msg_DEI2=2;
                        Cont_Msg_DEI1=0;
                        Cont_Msg_DEI0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_DEI1++;
                    if (Cont_Msg_DEI1 >= 3){                    
                        Park_DEI(1);
                        Park_Sound[1] = 1;
                        Cont_Msg_DEI3=0;
                        Cont_Msg_DEI2=0;
                        Cont_Msg_DEI1=2;
                        Cont_Msg_DEI0=0;
                    }    
                break;


                default:
                    Cont_Msg_DEI0++;
                    if (Cont_Msg_DEI0 >= 3){
                        Park_DEI(0);
                        Park_Sound[1] = 0;
                        Cont_Msg_DEI3=0;
                        Cont_Msg_DEI2=0;
                        Cont_Msg_DEI1=0;
                        Cont_Msg_DEI0=2;
                    }
                break;                

            }


            // Gestion DC (DCI + DCD)
            if (msg_p_0x001_dato2_B > msg_p_0x001_dato3_B)
            {
                msg_p_0x001_dato2_B = msg_p_0x001_dato3_B;   // tomar el valor más bajo de los sensores centrales.
            }
            
            switch (msg_p_0x001_dato2_B) {
                
                case 0 ... 18:  // compensado saliente parachoques.
                    Cont_Msg_DC3++;
                    if (Cont_Msg_DC3 >= 3){                    
                    Park_DC(3);
                    Park_Sound[2] = 3;
                        Cont_Msg_DC3=2;
                        Cont_Msg_DC2=0;
                        Cont_Msg_DC1=0;
                        Cont_Msg_DC0=0;
                    } 
                break;


                case 19 ... 31:
                    Cont_Msg_DC2++;
                    if (Cont_Msg_DC2 >= 3){                    
                        Park_DC(2);
                        Park_Sound[2] = 2;
                        Cont_Msg_DC3=0;
                        Cont_Msg_DC2=2;
                        Cont_Msg_DC1=0;
                        Cont_Msg_DC0=0;
                    }
                break;


                case 32 ... 56:
                    Cont_Msg_DC1++;
                    if (Cont_Msg_DC1 >= 3){                    
                    Park_DC(1);
                    Park_Sound[2] = 1;
                        Cont_Msg_DC3=0;
                        Cont_Msg_DC2=0;
                        Cont_Msg_DC1=2;
                        Cont_Msg_DC0=0;
                    }    
                break;


                default:
                    Cont_Msg_DC0++;
                    if (Cont_Msg_DC0 >= 3){
                    Park_DC(0);
                    Park_Sound[2] = 0;
                        Cont_Msg_DC3=0;
                        Cont_Msg_DC2=0;
                        Cont_Msg_DC1=0;
                        Cont_Msg_DC0=2;
                    }
                break;
                
            }


            // Gestion DED
            switch (msg_p_0x001_dato4_B) {                
                
                case 0 ... 12:
                    Cont_Msg_DED3++;
                    if (Cont_Msg_DED3 >= 3){                    
                        Park_DED(3);
                        Park_Sound[3] = 3;
                        Cont_Msg_DED3=2;
                        Cont_Msg_DED2=0;
                        Cont_Msg_DED1=0;
                        Cont_Msg_DED0=0;                      
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_DED2++;
                    if (Cont_Msg_DED2 >= 3){                    
                        Park_DED(2);
                        Park_Sound[3] = 2;
                        Cont_Msg_DED3=0;
                        Cont_Msg_DED2=2;
                        Cont_Msg_DED1=0;
                        Cont_Msg_DED0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_DED1++;
                    if (Cont_Msg_DED1 >= 3){                    
                        Park_DED(1);
                        Park_Sound[3] = 1;
                        Cont_Msg_DED3=0;
                        Cont_Msg_DED2=0;
                        Cont_Msg_DED1=2;
                        Cont_Msg_DED0=0;
                    }    
                break;


                default:
                    Cont_Msg_DED0++;
                    if (Cont_Msg_DED0 >= 3){
                        Park_DED(0);
                        Park_Sound[3] = 0;
                        Cont_Msg_DED3=0;
                        Cont_Msg_DED2=0;
                        Cont_Msg_DED1=0;
                        Cont_Msg_DED0=2;
                    }
                break;
                
            }


            // Gestion DLD
            switch (msg_p_0x001_dato5_B) {
                                                
                case 0 ... 12:
                    Cont_Msg_DLD3++;
                    if (Cont_Msg_DLD3 >= 3){                    
                        Park_DLD(3);
                        Park_Sound[4] = 3;
                        Cont_Msg_DLD3=2;
                        Cont_Msg_DLD2=0;
                        Cont_Msg_DLD1=0;
                        Cont_Msg_DLD0=0;
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_DLD2++;
                    if (Cont_Msg_DLD2 >= 3){                    
                        Park_DLD(2);
                        Park_Sound[4] = 2;
                        Cont_Msg_DLD3=0;
                        Cont_Msg_DLD2=2;
                        Cont_Msg_DLD1=0;
                        Cont_Msg_DLD0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_DLD1++;
                    if (Cont_Msg_DLD1 >= 3){                    
                        Park_DLD(1);
                        Park_Sound[4] = 1;
                        Cont_Msg_DLD3=0;
                        Cont_Msg_DLD2=0;
                        Cont_Msg_DLD1=2;
                        Cont_Msg_DLD0=0;
                    }    
                break;
            

                default:
                    Cont_Msg_DLD0++;
                    if (Cont_Msg_DLD0 >= 3){
                        Park_DLD(0);
                        Park_Sound[4] = 0;
                        Cont_Msg_DLD3=0;
                        Cont_Msg_DLD2=0;
                        Cont_Msg_DLD1=0;
                        Cont_Msg_DLD0=2;
                    }
                break;                
                
                
            }  
            
        }
        
    }
//----------------------------------------------//
    


//----------------------------------------------//
//  Mensajes sensores traseros.
//----------------------------------------------//
    if (msg_p_0x002) {
            
        msg_p_0x002 = false;
        
        if ( (msg_p_0x002_dato0 != msg_p_0x002_dato0_B) || (msg_p_0x002_dato1 != msg_p_0x002_dato1_B) || (msg_p_0x002_dato2 != msg_p_0x002_dato2_B) || 
                (msg_p_0x002_dato3 != msg_p_0x002_dato3_B) || (msg_p_0x002_dato4 != msg_p_0x002_dato4_B) || (msg_p_0x002_dato5 != msg_p_0x002_dato5_B)  )  {
                
            msg_p_0x002_dato0_B = msg_p_0x002_dato0;
            msg_p_0x002_dato1_B = msg_p_0x002_dato1;
            msg_p_0x002_dato2_B = msg_p_0x002_dato2;
            msg_p_0x002_dato3_B = msg_p_0x002_dato3;
            msg_p_0x002_dato4_B = msg_p_0x002_dato4;
            msg_p_0x002_dato5_B = msg_p_0x002_dato5;
             
            /*            
            tft->set_font((unsigned char*) Arial15x19);
            tft->locate(20,140);
            tft->printf(" %d %d    %d %d    %d %d ", (int)msg_p_0x002_dato0 * 2, (int)msg_p_0x002_dato1 * 2, (int)msg_p_0x002_dato2 * 2, (int)msg_p_0x002_dato3 * 2, (int)msg_p_0x002_dato4 * 2, (int)msg_p_0x002_dato5 * 2);
            */
            
            //*********************************************
            //  Mostrar estado en pantalla:
            //     0 ... 255              0cm ... 500cm
            //
            //  0...    12      >>      0cm...      24cm    Rojo
            //  13...   25      >>      >28cm...    50cm    Amarillo.
            //  26...   50      >>      >84cm...    100cm   Verde.
            //  >100cm          No mostrar.            
            //            
            //  Numeracion sensores:
            //    5:TLI   6:TEI   7:TC    8:TED   9:TLD
            //*********************************************

            // Gestion TLI
            switch (msg_p_0x002_dato0_B) {

                case 0 ... 12:
                    Cont_Msg_TLI3++;
                    if (Cont_Msg_TLI3 >= 2){                    
                        Park_TLI(3);
                        Park_Sound[5] = 3;
                        TrafC_Izq_OFF();
                        Cont_Msg_TLI3=2;
                        Cont_Msg_TLI2=0;
                        Cont_Msg_TLI1=0;
                        Cont_Msg_TLI0=0;
                        Cont_Msg_TLI4=0;                        
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_TLI2++;
                    if (Cont_Msg_TLI2 >= 2){                    
                        Park_TLI(2);
                        Park_Sound[5] = 2;
                        TrafC_Izq_OFF();
                        Cont_Msg_TLI3=0;
                        Cont_Msg_TLI2=2;
                        Cont_Msg_TLI1=0;
                        Cont_Msg_TLI0=0;
                        Cont_Msg_TLI4=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_TLI1++;
                    if (Cont_Msg_TLI1 >= 2){   
                        Park_TLI(1);
                        Park_Sound[5] = 1;
                        TrafC_Izq_OFF();
                        Cont_Msg_TLI3=0;
                        Cont_Msg_TLI2=0;
                        Cont_Msg_TLI1=2;
                        Cont_Msg_TLI0=0;
                        Cont_Msg_TLI4=0;
                    }    
                break;
            
                
                case 51 ... 250:
                    if (retroceso_ON && Detector_Traf_Cruzado) { // Comprobar tráfico cruzado marcha atrás y durante el perido de inicio de uso vehiculo.
                        Cont_Msg_TLI4++;
                        if (Cont_Msg_TLI4 >= 2){
                            Park_TLI(0);
                            TrafC_Izq_ON();
                            Park_Sound[5] = 4;
                            Cont_Msg_TLI3=0;
                            Cont_Msg_TLI2=0;
                            Cont_Msg_TLI1=0;
                            Cont_Msg_TLI0=0;
                            Cont_Msg_TLI4=2;
                        }                    
                    }                
                break;


                default:
                    Cont_Msg_TLI0++;
                    if (Cont_Msg_TLI0 >= 2){
                        Park_TLI(0);
                        Park_Sound[5] = 0;
                        TrafC_Izq_OFF();
                        Cont_Msg_TLI3=0;
                        Cont_Msg_TLI2=0;
                        Cont_Msg_TLI1=0;
                        Cont_Msg_TLI0=2;
                        Cont_Msg_TLI4=0;
                    }
                break;

            }



            // Gestion TEI
            switch (msg_p_0x002_dato1_B) {

                case 0 ... 12:
                    Cont_Msg_TEI3++;
                    if (Cont_Msg_TEI3 >= 2){                    
                        Park_TEI(3);
                        Park_Sound[6] = 3;
                        Cont_Msg_TEI3=2;
                        Cont_Msg_TEI2=0;
                        Cont_Msg_TEI1=0;
                        Cont_Msg_TEI0=0;
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_TEI2++;
                    if (Cont_Msg_TEI2 >= 2){                    
                        Park_TEI(2);
                        Park_Sound[6] = 2;
                        Cont_Msg_TEI3=0;
                        Cont_Msg_TEI2=2;
                        Cont_Msg_TEI1=0;
                        Cont_Msg_TEI0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_TEI1++;
                    if (Cont_Msg_TEI1 >= 2){                    
                        Park_TEI(1);
                        Park_Sound[6] = 1;
                        Cont_Msg_TEI3=0;
                        Cont_Msg_TEI2=0;
                        Cont_Msg_TEI1=2;
                        Cont_Msg_TEI0=0;
                    }    
                break;


                default:
                    Cont_Msg_TEI0++;
                    if (Cont_Msg_TEI0 >= 2){
                        Park_TEI(0);
                        Park_Sound[6] = 0;
                        Cont_Msg_TEI3=0;
                        Cont_Msg_TEI2=0;
                        Cont_Msg_TEI1=0;
                        Cont_Msg_TEI0=2;
                    }
                break;

            }


            // Gestion TC (TCI + TCD)
            if (msg_p_0x002_dato2_B > msg_p_0x002_dato3_B)
            {
                msg_p_0x002_dato2_B = msg_p_0x002_dato3_B;   // tomar el valor más bajo de los sensores centrales.
            }
            
            switch (msg_p_0x002_dato2_B) {

                case 0 ... 12:
                    Cont_Msg_TC3++;
                    if (Cont_Msg_TC3 >= 2){                    
                        Park_TC(3);
                        Park_Sound[7] = 3;
                        Cont_Msg_TC3=2;
                        Cont_Msg_TC2=0;
                        Cont_Msg_TC1=0;
                        Cont_Msg_TC0=0;
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_TC2++;
                    if (Cont_Msg_TC2 >= 2){                    
                        Park_TC(2);
                        Park_Sound[7] = 2;
                        Cont_Msg_TC3=0;
                        Cont_Msg_TC2=2;
                        Cont_Msg_TC1=0;
                        Cont_Msg_TC0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_TC1++;
                    if (Cont_Msg_TC1 >= 2){                    
                        Park_TC(1);
                        Park_Sound[7] = 1;
                        Cont_Msg_TC3=0;
                        Cont_Msg_TC2=0;
                        Cont_Msg_TC1=2;
                        Cont_Msg_TC0=0;
                    }    
                break;


                default:
                    Cont_Msg_TC0++;
                    if (Cont_Msg_TC0 >= 2){
                        Park_TC(0);
                        Park_Sound[7] = 0;
                        Cont_Msg_TC3=0;
                        Cont_Msg_TC2=0;
                        Cont_Msg_TC1=0;
                        Cont_Msg_TC0=2;
                    }
                break;

            }


            // Gestion TED
            switch (msg_p_0x002_dato4_B) {
                
                case 0 ... 12:
                    Cont_Msg_TED3++;
                    if (Cont_Msg_TED3 >= 2){                    
                        Park_TED(3);
                        Park_Sound[8] = 3;
                        Cont_Msg_TED3=2;
                        Cont_Msg_TED2=0;
                        Cont_Msg_TED1=0;
                        Cont_Msg_TED0=0;                      
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_TED2++;
                    if (Cont_Msg_TED2 >= 2){                    
                        Park_TED(2);
                        Park_Sound[8] = 2;
                        Cont_Msg_TED3=0;
                        Cont_Msg_TED2=2;
                        Cont_Msg_TED1=0;
                        Cont_Msg_TED0=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_TED1++;
                    if (Cont_Msg_TED1 >= 2){                    
                        Park_TED(1);
                        Park_Sound[8] = 1;
                        Cont_Msg_TED3=0;
                        Cont_Msg_TED2=0;
                        Cont_Msg_TED1=2;
                        Cont_Msg_TED0=0;
                    }    
                break;


                default:
                    Cont_Msg_TED0++;
                    if (Cont_Msg_TED0 >= 2){
                        Park_TED(0);
                        Park_Sound[8] = 0;
                        Cont_Msg_TED3=0;
                        Cont_Msg_TED2=0;
                        Cont_Msg_TED1=0;
                        Cont_Msg_TED0=2;
                    }
                break;

            }


            // Gestion TLD
            switch (msg_p_0x002_dato5_B) {
                
                case 0 ... 12:
                    Cont_Msg_TLD3++;
                    if (Cont_Msg_TLD3 >= 2){                    
                        Park_TLD(3);
                        Park_Sound[9] = 3;
                        TrafC_Der_OFF();
                        Cont_Msg_TLD3=2;
                        Cont_Msg_TLD2=0;
                        Cont_Msg_TLD1=0;
                        Cont_Msg_TLD0=0;
                        Cont_Msg_TLD4=0;                        
                    }
                break;


                case 13 ... 25:
                    Cont_Msg_TLD2++;
                    if (Cont_Msg_TLD2 >= 2){                    
                        Park_TLD(2);
                        Park_Sound[9] = 2;
                        TrafC_Der_OFF();
                        Cont_Msg_TLD3=0;
                        Cont_Msg_TLD2=2;
                        Cont_Msg_TLD1=0;
                        Cont_Msg_TLD0=0;
                        Cont_Msg_TLD4=0;
                    }
                break;


                case 26 ... 50:
                    Cont_Msg_TLD1++;
                    if (Cont_Msg_TLD1 >= 2){                    
                        Park_TLD(1);
                        Park_Sound[9] = 1;
                        TrafC_Der_OFF();
                        Cont_Msg_TLD3=0;
                        Cont_Msg_TLD2=0;
                        Cont_Msg_TLD1=2;
                        Cont_Msg_TLD0=0;
                        Cont_Msg_TLD4=0;
                    }    
                break;
            
                
                case 51 ... 250:
                    if (retroceso_ON && Detector_Traf_Cruzado) { // Comprobar tráfico cruzado marcha atrás y durante el perido de inicio de uso vehiculo.
                        Cont_Msg_TLD4++;
                        if (Cont_Msg_TLD4 >= 2){
                            Park_TLD(0);
                            TrafC_Der_ON();
                            Park_Sound[9] = 4;
                            Cont_Msg_TLD3=0;
                            Cont_Msg_TLD2=0;
                            Cont_Msg_TLD1=0;
                            Cont_Msg_TLD0=0;
                            Cont_Msg_TLD4=2;
                        }                    
                    }                
                break;


                default:
                    Cont_Msg_TLD0++;
                    if (Cont_Msg_TLD0 >= 2){
                        Park_TLD(0);
                        Park_Sound[9] = 0;
                        TrafC_Der_OFF();
                        Cont_Msg_TLD3=0;
                        Cont_Msg_TLD2=0;
                        Cont_Msg_TLD1=0;
                        Cont_Msg_TLD0=2;
                        Cont_Msg_TLD4=0;
                    }
                break;
            }  

            
        }

        
    }
//----------------------------------------------//




//----------------------------------------------//
// GESTIÓN DEL SONIDO

    Park_Sound_Play = Park_Sound[0];
    
    for (int i=1; i<12; i++){   // Rastrear aviso acústico con mayor prioridad (0 menor .....  3 mayor) 
        if (Park_Sound_Play < Park_Sound[i]) Park_Sound_Play = Park_Sound[i];
    }
    
    //******************************************
    // Park_Sound_Play 0:  No hay sonido.
    // Park_Sound_Play 1:  Beep cada 0.8seg.
    // Park_Sound_Play 2:  Beep cada 0.3seg.
    // Park_Sound_Play 3:  Beep continuo.
    //******************************************
    if ((Park_Sound_Play_B != Park_Sound_Play) & (msg_0x0B6_dato0>1 ) ) { // Aviso acústico solo cuando está en el motor en marcha. 
    
        Park_Sound_Play_B = Park_Sound_Play;
        
        switch (Park_Sound_Play) {
                    
            case 0:
                Sound_2.detach();
                buzzer=0.0; // turn off audio
            break;
    
            case 1:
                Sound_2.attach(&Sound_2_Beep, 0.6);     // 0.6
            break;
    
            case 2:
                Sound_2.attach(&Sound_2_Beep, 0.3);     // 0.3
            break;
    
            case 3:
                Sound_2.detach();
                Beep(0);
            break;
            

                case 4:
                    Sound_2.attach(&Sound_2_Beep, 0.15);  
                break;
            
    
            default:
                Sound_2.detach();
                buzzer=0.0; // turn off audio
            break;
                }    
    }
    
}
//----------------------------------------------//



/************************************************
    Gestión sistema BSD.
*************************************************/    
void Gestion_BSD(void)
{
    // Activacion BSD.
    if ( (velocidad > 50) && !activo_BSD ) {
        activo_BSD = true;     // Evitar reentradas.
        
        tft->Bitmap(126,170,70,35,(unsigned char *)Imagen_BSD);
        
        can_p.write(CANMessage(0x003, CAN_msg_p_MB, 1));   // Activar Modo BSD.
        
        msg_p_0x002_dato0_B = 0;   // Forzar actualizar medidas.
        msg_p_0x002_dato1_B = 0;   // Forzar actualizar medidas.
        msg_p_0x002_dato2_B = 0;   // Forzar actualizar medidas.
        msg_p_0x002_dato3_B = 0;   // Forzar actualizar medidas.
        msg_p_0x002_dato4_B = 0;   // Forzar actualizar medidas.
        msg_p_0x002_dato5_B = 0;   // Forzar actualizar medidas.
    }
                
    // Desactivacion BSD.
    if ( (velocidad < 30) && activo_BSD) {
        activo_BSD = false;     // Evitar reentradas.
        tft->fillrect(126, 170, 196, 206, Black);
        can_p.write(CANMessage(0x003, CAN_msg_p_MR, 1));   // Activar Modo Reposo.
    }

    // Gestion activacion BSD.
    if (activo_BSD && msg_p_0x002) { // Nuevo mensage de sensores y BSS activo?
        
        msg_p_0x002 = false;
        
        // Diferente a la lectura anterior?   Evitar reentradas.
        if ( (msg_p_0x002_dato0 != msg_p_0x002_dato0_B) || (msg_p_0x002_dato1 != msg_p_0x002_dato1_B) || (msg_p_0x002_dato2 != msg_p_0x002_dato2_B) || 
                (msg_p_0x002_dato3 != msg_p_0x002_dato3_B) || (msg_p_0x002_dato4 != msg_p_0x002_dato4_B) || (msg_p_0x002_dato5 != msg_p_0x002_dato5_B)  )  {
                
            msg_p_0x002_dato0_B = msg_p_0x002_dato0;
            msg_p_0x002_dato1_B = msg_p_0x002_dato1;
            msg_p_0x002_dato2_B = msg_p_0x002_dato2;
            msg_p_0x002_dato3_B = msg_p_0x002_dato3;
            msg_p_0x002_dato4_B = msg_p_0x002_dato4;
            msg_p_0x002_dato5_B = msg_p_0x002_dato5;
            
            // Activación BSD izquierdo para obstaculo < 350 cm.
            //if (izquierda_ON && ((msg_p_0x002_dato0 * 2)<400)) {
            if ( (msg_p_0x002_dato0 * 2) < 350 ) {
                BSD_izq_Alarm_Imagen = true;
                //BSD_izq_Alarm_Imagen_F = false;
                BSD_intermitente_izq.attach(&BSD_izq_OFF, 3.0);
                
                if (izquierda_ON)   // Señalizar alarma obstaculo a la izquierda.
                    Beep(2);
            } 
            
            // Activación BSD derecha para obstaculo < 350 cm.
            //if (derecha_ON && ((msg_p_0x002_dato5 * 2) <400)) {
            if ( (msg_p_0x002_dato5 * 2) < 350 ) {
                BSD_der_Alarm_Imagen = true;
                //BSD_der_Alarm_Imagen_F = false;
                BSD_intermitente_der.attach(&BSD_der_OFF, 3.0);
                
                if (derecha_ON)     // Señalizar alarma obstaculo a la derecha.
                    Beep(2);
            }                        
        }
    }


    if (BSD_izq_Alarm_Imagen && !BSD_izq_Alarm_Imagen_F ) {        
        BSD_izq_Alarm_Imagen_F = true;
        
        tft->Bitmap(92,175,30,26,(unsigned char *)Imagen_peligro); // Aviso peligro izquierda.
        }
        
    if (BSD_izq_NoAlarm_Imagen) {
        BSD_izq_NoAlarm_Imagen = false;
        BSD_izq_Alarm_Imagen = false;
        BSD_izq_Alarm_Imagen_F = false;

        tft->fillrect(92, 175, 122, 201, Black); // Borrado aviso peligro izq.            
        }        

            
    if (BSD_der_Alarm_Imagen && !BSD_der_Alarm_Imagen_F) {
        BSD_der_Alarm_Imagen_F = true;

        tft->Bitmap(200,175,30,26,(unsigned char *)Imagen_peligro); // Aviso peligro derecha.
        }

    if (BSD_der_NoAlarm_Imagen) {
        BSD_der_NoAlarm_Imagen = false;
        BSD_der_Alarm_Imagen = false;
        BSD_der_Alarm_Imagen_F = false;
        
        tft->fillrect(200, 175, 230, 201, Black);   // Borrado aviso peligro derecha.
        }

}



/************************************************
    Encender backlight.
*************************************************/    
void UP_backlight(float tiempo)
{ 
    // Arranque creciente luminosidad backlight
    double   c, cc;
    
    
    if (msg_0x128_dato4 & 0x80)
        cc = Min_backlight;
    else    
        cc = Max_backlight;

        
    for(c=1; c <= cc; c = c+0.05){
        backlight.write(c/100);  // c% duty cycle   
        wait( tiempo/(cc*16) );
        
    }

}



/************************************************
    Apagar backlight.
*************************************************/    
void DOWN_backlight(float tiempo)
{ 
    // Apagado suave luminosidad backlight
    double   c, cc;
    
    
    if (msg_0x128_dato4 & 0x80)
        cc = Min_backlight;
    else    
        cc = Max_backlight;

        
    for(c=cc; c >= 0; c = c-0.05){
        backlight.write(c/100);  // c% duty cycle   
        wait( tiempo/(cc*16) );
    }

}



/************************************************
    Bucle Principal. MAIN
*************************************************/    
int main()
{   
    // Ini. ILI9341.  type,    speed,   mosi,  miso,  sclk,   cs,    reset,   dc
    tft = new ILI9341(SPI_8, 10000000,  PB_5,  PB_4,  PB_3,  PB_10,  PA_12,  PA_11, "tft"); 
    tft->set_orientation(1);     
    
    // Control brillo pantalla.
    backlight.period(0.005);
    backlight.write(0.0f);  // 50% duty cycle
    
    // Formato y Filtro CAN CONFORT (0... 13 filtros)
    msg.format = CANStandard;
    can.filter(0x0B6, 0x7FF, CANStandard, 0);
    can.filter(0x0F6, 0x7FF, CANStandard, 1);
    can.filter(0x128, 0x7FF, CANStandard, 2);
    can.filter(0x161, 0x7FF, CANStandard, 3);
    can.filter(0x168, 0x7FF, CANStandard, 4);
    can.filter(0x21F, 0x7FF, CANStandard, 5); // Mando volante.
    
    // Formato y Filtro CAN PARK  (14... 27 filtros)
    msg_p.format = CANStandard;
    can_p.filter(0x001, 0x7FF, CANStandard, 14); // Filtro ID:001, ID:002
    can_p.filter(0x002, 0x7FF, CANStandard, 15); // Filtro ID:001, ID:002

    can.attach(callback(&can_irq), CAN::RxIrq); // Habilitar irq`s Rx CAN CONFORT.
    can_p.attach(callback(&can_p_irq), CAN::RxIrq); // Habilitar irq`s Rx CAN PARK.
    
    tic_rate_velocidad.attach(&met_rate_velocidad, 0.3); //Cadencia de actualización valor velocidad en pantalla.
    
    tft->foreground(0xFFFF);           // color caracteres 
    tft->background(0x0000);           // color fondo negro

    if (!pulsador) {Mantenimiento();}
    
            
    while(true){
       
        Gestion_msg();
        
        // Gestion global. 
        // Estados sitema: REPOSO, PRESENTACION, PRINCIPAL_1, PRINCIPAL_2, APARCAMIENTO, CIERRE.  
        switch (state_FSM_sistem) {
                
            case PRESENTACION:  // Mantener pantalla Principal_1 hasta contacto_ON.

                if (contacto_ON) state_FSM_sistem = PRINCIPAL_1;
                if (!combine_ON) state_FSM_sistem = CIERRE;

            break;


            case PRINCIPAL_1:   // Mostrar pantalla principal sin datos.

                if (!pasado_PRINCIPAL_1) {              // Solo se ejecuta la primera vez. Presentacion indicadores.
                    pasado_PRINCIPAL_1 = true;
                    
                    /*
                    for(int g=0; g<100; g = g+4){       // Marcar nivel ascendiente. g+6
                        Indic_Temperatura((g+60)/1.25);                        
                        Indic_Combustible(g);
                    }
                    */
                    
                    for(int g=0; g<119; g++){           // Marcar nivel ascendiente. ********************************
                        Indic_Temperatura_Present(g);                        
                        Indic_Combustible_Present(g);
                        wait_ms(5);
                    }
                    
                    
                    for(int g=100; g>0; g = g-6){       // Marcar nivel descendiente y quedarse en el valor real. g-6
                        if ((msg_0x0F6_dato1 - 39) <  (g+60)/1.25    ) {
                            Indic_Temperatura((g+60)/1.25);
                        }
                        if (msg_0x161_dato3 < g) {
                             Indic_Combustible(g);
                        }
                    }
                    
                    
                    Traf_Cruzado.attach(&Traf_Cruzado_OFF, 120.0); // Activar temporizacion para el uso de Aviso Trafico Cruzado.
                                                                   // Solo se activa al comienzo de uso de vehiculo.
                }
                
                
                        msg_0x0B6_dato2_B = 0;  // Forzar actualizar "velocidad"   ********************************
                msg_0x0F6_dato1_B = 0;  // Forzar actualizar "temperatura refrigerante"
                msg_0x128_dato0_B = 0;  // Forzar actualizar "reserva"
                msg_0x161_dato3_B = 0;  // Forzar actualizar "nivel de combustible"
                msg_0x168_dato0_B = 0;  // Forzar actualizar "sobretemperatura"
                
                state_FSM_sistem = PRINCIPAL_2;
                
            break;


            case PRINCIPAL_2:   // Actualizar datos pantalla principal.
                
                Gestion_BSD();                                
                
                if (retroceso_ON) {
                    DOWN_backlight(0.1);
                    Pantalla_A1();
                    UP_backlight(0.1);

                    Beep (0.05);
                    wait(.1);
                    Beep (0.2);
                    wait(.5);
                    
                    can_p.write(CANMessage(0x003, CAN_msg_p_MA, 1));   // Activar: Modo Parking sensores.
                    
                    Park_Sound_Play_B = 0;      // Forzar actualizar sonido.
                    msg_p_0x001_dato0_B = 254;    // Forzar actualizar medidas.
                    msg_p_0x002_dato0_B = 254;    // Forzar actualizar medidas.
                    
                    /*
                    msg_p_0x002_dato1_B = 254;    // Forzar actualizar medidas.
                    msg_p_0x002_dato2_B = 254;    // Forzar actualizar medidas.
                    msg_p_0x002_dato3_B = 254;    // Forzar actualizar medidas.
                    msg_p_0x002_dato4_B = 254;    // Forzar actualizar medidas.
                    msg_p_0x002_dato5_B = 254;    // Forzar actualizar medidas.
                    */                    
                    
                    Cont_Msg_DLI0 = 0; Cont_Msg_DLI1 = 0; Cont_Msg_DLI2 = 0; Cont_Msg_DLI3 = 0; Cont_Msg_DLI4 = 0;
                    Cont_Msg_DEI0 = 0; Cont_Msg_DEI1 = 0; Cont_Msg_DEI2 = 0; Cont_Msg_DEI3 = 0;
                    Cont_Msg_DC0 = 0;  Cont_Msg_DC1 = 0;  Cont_Msg_DC2 = 0;  Cont_Msg_DC3 = 0;
                    Cont_Msg_DLD0 = 0; Cont_Msg_DLD1 = 0; Cont_Msg_DLD2 = 0; Cont_Msg_DLD3 = 0; Cont_Msg_DLD4 = 0;
                    Cont_Msg_DED0 = 0; Cont_Msg_DED1 = 0; Cont_Msg_DED2 = 0; Cont_Msg_DED3 = 0;
                    
                    Cont_Msg_TLI0 = 0; Cont_Msg_TLI1 = 0; Cont_Msg_TLI2 = 0; Cont_Msg_TLI3 = 0; Cont_Msg_TLI4 = 0;
                    Cont_Msg_TEI0 = 0; Cont_Msg_TEI1 = 0; Cont_Msg_TEI2 = 0; Cont_Msg_TEI3 = 0;
                    Cont_Msg_TC0 = 0; Cont_Msg_TC1 = 0; Cont_Msg_TC2 = 0; Cont_Msg_TC3 = 0;
                    Cont_Msg_TLD0 = 0; Cont_Msg_TLD1 = 0; Cont_Msg_TLD2 = 0; Cont_Msg_TLD3 = 0; Cont_Msg_TLD4 = 0;
                    Cont_Msg_TED0 = 0; Cont_Msg_TED1 = 0; Cont_Msg_TED2 = 0; Cont_Msg_TED3 = 0;
                    
                    // Mostrar si esta activado el sistema de alerta de trafico cruzado.
                    if (Detector_Traf_Cruzado){ // Reiniciar contador si se mantiene maniobra al comienzo de uso de vehiculo.
                        tft->set_font((unsigned char*) Arial15x19);
                        tft->locate(20,215);
                        tft->printf(">>>");
                        tft->locate(280,215);
                        tft->printf("<<<");                        
                    }
                    else {
                        tft->set_font((unsigned char*) Arial15x19);
                        tft->locate(20,215);
                        tft->printf("   ");
                        tft->locate(280,215);
                        tft->printf("   ");                
                    }
                    
                    state_FSM_sistem = APARCAMIENTO;
                }
                if (!combine_ON) state_FSM_sistem = CIERRE;
                if (!contacto_ON) {
                    Pantalla_P1();
                    state_FSM_sistem = PRESENTACION;
                }
                
            break;


            case APARCAMIENTO:  //  Gestion Modo Aparcamiento.

                Gestion_msg_p();
                
                if (Detector_Traf_Cruzado){ // Reiniciar contador si se mantiene maniobra al comienzo de uso de vehiculo.
                    Traf_Cruzado.attach(&Traf_Cruzado_OFF, 120.0); // Activar temporizacion para el uso de Aviso Trafico Cruzado.
                                                                   // Solo se activa al comienzo de uso de vehiculo.              
                }
                
                // ***************************** Volver a pantalla principal *****************************************
                if ( (!retroceso_ON) && (( (((msg_0x0B6_dato2 << 8) + msg_0x0B6_dato3) / 100)) > 10 )){ // volver a pantalla principal >10km/h
                    can_p.write(CANMessage(0x003, CAN_msg_p_MR, 1));   // Activar Modo Reposo.
                    msg_0x0F6_dato1_B = 0;  // Forzar actualizar "temperatura refrigerante"
                    msg_0x128_dato0_B = 0;  // Forzar actualizar "reserva"
                    msg_0x161_dato3_B = 0;  // Forzar actualizar "nivel de combustible"
                    msg_0x168_dato0_B = 0;  // Forzar actualizar "sobretemperatura"
                    Sound_2.detach();       // turn off audio
                    buzzer=0.0;             // turn off audio
                    DOWN_backlight(0.1);    
                    Pantalla_P1();
                    UP_backlight(0.1);
                    state_FSM_sistem = PRINCIPAL_2;
                }
                // ****************************************************************************************************

                
                // ************************************ Apagar sistema  ***********************************************
                if (!combine_ON) {
                    can_p.write(CANMessage(0x003, CAN_msg_p_MR, 1));   // Activar Modo Reposo.
                    state_FSM_sistem = CIERRE;
                    Sound_2.detach();   // turn off audio
                    buzzer=0.0;         // turn off audio
                }
                if (!contacto_ON) {
                    can_p.write(CANMessage(0x003, CAN_msg_p_MR, 1));   // Activar Modo Reposo.
                    Sound_2.detach();   // turn off audio
                    buzzer=0.0;         // turn off audio
                    DOWN_backlight(0.1);
                    Pantalla_P1();
                    UP_backlight(1);
                    state_FSM_sistem = PRESENTACION;
                }
                // *****************************************************************************************************
                
            break;


            case CIERRE:    //  Gestion pantalla TRIP.

                tft->Bitmap(0,0,320,240,(unsigned char *)Imagen_Logo);  // Presentar Logo.
                DOWN_backlight(1);          // Apagado suave backlight y dejar de mostrar logo.
                backlight.write(0);         // asegurar brillo 0.
                state_FSM_sistem = REPOSO;
                
            break;


            default:        //  REPOSO. Alimentacion del sistema.
            
                if (combine_ON) {    // Activar presentación cuando hay actividad.
                    tft->Bitmap(0,0,320,240,(unsigned char *)Imagen_Logo);  // Presentar Logo.
                    UP_backlight(1);        // Encender pantalla.
                    wait(2);                // Mantener Logo 2 seg.
                    DOWN_backlight(0.1);    // Bajar progresivo brillo.
                    Pantalla_P1();          // Presentar Pantalla_P1 sin datos.
                    UP_backlight(0.1);      // Iluminar pantalla.

                    state_FSM_sistem = PRESENTACION;
                }
                                      
        }


    }


}
      
