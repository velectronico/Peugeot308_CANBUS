
#ifndef CONTROL_TRIP_H
#define CONTROL_TRIP_H

#include "main.h"

void Control_TRIP(void);


#endif