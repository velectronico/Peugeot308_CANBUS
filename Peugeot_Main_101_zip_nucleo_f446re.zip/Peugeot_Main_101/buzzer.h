
#ifndef BUZZER_H
#define BUZZER_H

#include "main.h"


void Beep(float TimeSound);


#endif