#ifndef PANTALLA_A1_H
#define PANTALLA_A1_H

#include "main.h"

void Pantalla_A1(void);

void Park_DLI(int color);
void Park_DEI(int color);
void Park_DC(int color);
void Park_DLD(int color);
void Park_DED(int color);
void Park_DLD(int color);

void Park_TLI(int color);
void Park_TEI(int color);
void Park_TC(int color);
void Park_TLD(int color);
void Park_TED(int color);
void Park_TLD(int color);

void TrafC_Izq_ON(void);
void TrafC_Der_ON(void);
void TrafC_Izq_OFF(void);
void TrafC_Der_OFF(void);


#endif