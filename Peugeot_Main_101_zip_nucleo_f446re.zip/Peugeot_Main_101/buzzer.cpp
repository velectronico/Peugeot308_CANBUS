#include "main.h"
#include "buzzer.h"

Timeout TimeBeep;


void F_TimeBeep() {
    buzzer=0.0; // turn off audio
}


/************************************************
    Sonido buzzer.
*************************************************/
void Beep(float TimeSound) {

    TimeBeep.attach(&F_TimeBeep, TimeSound);
    buzzer.period(1.0/800.0); // 800hz period
    buzzer =0.50; //50% duty cycle - mid range volume
    //buzzer =0.01; // minimo volumen
}
