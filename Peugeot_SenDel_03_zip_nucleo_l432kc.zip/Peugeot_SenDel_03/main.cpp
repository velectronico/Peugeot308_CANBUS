/**************************************************************************************
GESTION SENSORES ULTRASONIDOS DELANTEROS
***************************************************************************************
Tx (ID 001): 

Modo Parking    Dato*2 = cm
        (0)0xTT     Delantero   Lateral     Izquierdo.  (0...512 cm)
        (1)0xTT     Delantero   Esquina     Izquierdo.  (0...512 cm)
        (2)0xTT     Delantero   Central     Izquierdo.  (0...512 cm)
        (3)0xTT     Delantero   Central     Derecho.    (0...512 cm)
        (4)0xTT     Delantero   Esquina     Derecho.    (0...512 cm)
        (5)0xTT     Delantero   Lateral     Derecho.    (0...512 cm)
        (6)0xTT
        (7)0xTT

Modo BSD = Modo REPOSO

Rx  (ID 003);
        (0)0xMM     MM=00   Modo    REPOSO
                    MM=01   Modo    BSD
                    MM=02   Modo    APARCAMIENTO     
***************************************************************************************/

#include "mbed.h"
#include "hcsr04.h"

DigitalOut  led(LED1);


HCSR04  sensorDLI(PB_5,PA_0);   // TLD  Trig, Echo
HCSR04  sensorDEI(PA_8,PA_1);   // TED  Trig, Echo
HCSR04  sensorDCI(PB_1,PA_3);   // TCD  Trig, Echo
HCSR04  sensorDCD(PB_6,PA_4);   // TCI  Trig, Echo
HCSR04  sensorDED(PB_7,PA_5);   // TEI  Trig, Echo
HCSR04  sensorDLD(PB_0,PA_6);   // TLI  Trig, Echo


// CAN PARK
CAN         can_p (PA_11, PA_12, 125000);     // Rx, Tx, Frec   driver
CANMessage  msg_p;

// Distancias medidas
unsigned int distancia_DLD;
unsigned int distancia_DED;
unsigned int distancia_DCD;
unsigned int distancia_DCI;
unsigned int distancia_DEI;
unsigned int distancia_DLI;


// BACKUP's MSG CAN PARK. 
bool msg_p_0x003 = 0;

char msg_p_0x003_dato0;
char msg_p_0x003_dato0_B;

// Mensajes Tx CAN PARKING
char CAN_msg_p[8] =    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

// ESTADOS SISTEMAS
typedef enum {REPOSO, BSD, APARCAMIENTO} state_sistem;
state_sistem  state_FSM_sistem = REPOSO;


/************************************************
    Gestion interrupciones Rx CAN PARK
*************************************************/  
void can_p_irq() {
    
    if (can_p.read(msg_p)) {

        if(msg_p.id == 0x003){
            
            if(msg_p.data[0] == 0)  state_FSM_sistem = REPOSO;
            if(msg_p.data[0] == 1)  state_FSM_sistem = BSD;
            if(msg_p.data[0] == 2)  state_FSM_sistem = APARCAMIENTO;   
        }   
    }
}
/*************************************************/  


/************************************************
    Bucle Principal. MAIN
*************************************************/    
int main()
{        
    led=0;
    
    can_p.filter(0x003, 0x7FF, CANStandard, 0);   
    can_p.attach(callback(&can_p_irq), CAN::RxIrq); // Habilitar irq`s Rx CAN PARK.
          

    while(1) {

        switch (state_FSM_sistem) {
                
            case BSD:  // Sensores modo BSD.
  
                // NO HACER NADA

            break;


            case APARCAMIENTO:  //  Sensores modo aparcamiento.
                
                sensorDLI.start();    // (uS/58)   max.40ms = 686cm
                sensorDCI.start();
                sensorDED.start();
                wait_ms(70);
                sensorDLD.start();
                sensorDCD.start();
                sensorDEI.start();
                wait_ms(70);               
                
                distancia_DLI = sensorDLI.get_dist_cm();
                if (distancia_DLI < 500) 
                    CAN_msg_p[0] = int(distancia_DLI/2);
                else 
                    CAN_msg_p[0] = 255;
                
                distancia_DEI = sensorDEI.get_dist_cm();
                if (distancia_DEI < 500) 
                    CAN_msg_p[1] = int(distancia_DEI/2);
                else 
                    CAN_msg_p[1] = 255;
                
                distancia_DCI = sensorDCI.get_dist_cm();
                if (distancia_DCI < 500) 
                    CAN_msg_p[2] = int(distancia_DCI/2);
                else 
                    CAN_msg_p[2] = 255;


                distancia_DCD = sensorDCD.get_dist_cm();
                if (distancia_DCD < 500) 
                    CAN_msg_p[3] = int(distancia_DCD/2);
                else 
                    CAN_msg_p[3] = 255;

                distancia_DED = sensorDED.get_dist_cm();
                if (distancia_DED < 500) 
                    CAN_msg_p[4] = int(distancia_DED/2);
                else 
                    CAN_msg_p[4] = 255;
                
                distancia_DLD = sensorDLD.get_dist_cm();
                if (distancia_DLD < 500) 
                    CAN_msg_p[5] = int(distancia_DLD/2);
                else 
                    CAN_msg_p[5] = 255;
                
                
                CAN_msg_p[6] = 0x00;
                CAN_msg_p[7] = 0x00;
                can_p.write(CANMessage(0x001, CAN_msg_p, 8));
                
            break;


            default:            //  REPOSO.
 
                // NO HACER NADA

            break;      
        }
    
        wait_ms(20);
        led = !led;
    }
        
}
