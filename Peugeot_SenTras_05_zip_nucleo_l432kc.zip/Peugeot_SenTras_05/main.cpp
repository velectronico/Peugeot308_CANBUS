/**************************************************************************************
GESTION SENSORES ULTRASONIDOS TRASEROS
***************************************************************************************
Tx (ID 002): 

Modo Parking    Dato*2 = cm
        (0)0xTT     Trasero     Lateral     Izquierdo.  (0...512 cm)
        (1)0xTT     Trasero     Esquina     Izquierdo.  (0...512 cm)
        (2)0xTT     Trasero     Central     Izquierdo.  (0...512 cm)
        (3)0xTT     Trasero     Central     Derecho.    (0...512 cm)
        (4)0xTT     Trasero     Esquina     Derecho.    (0...512 cm)
        (5)0xTT     Trasero     Lateral     Derecho.    (0...512 cm)
        (6)0xTT
        (7)0xTT

Modo BSD        Dato*2 = cm
        (0)0xTT     Trasero     Lateral     Izquierdo.  (0...512 cm)
        (1)0xTT
        (2)0xTT     
        (3)0xTT     
        (4)0xTT
        (5)0xTT     Trasero     Lateral     Derecho.    (0...512 cm)
        (6)0xTT
        (7)0xTT

Rx  (ID 003);
        (0)0xMM     MM=00   Modo    REPOSO
                    MM=01   Modo    BSD
                    MM=02   Modo    APARCAMIENTO     
***************************************************************************************/

#include "mbed.h"
#include "hcsr04.h"

DigitalOut  led(LED1);
//Serial pc(USBTX, USBRX); // tx, rx


HCSR04  sensorTLI(PB_5,PA_0);   // TLD  Trig, Echo
HCSR04  sensorTEI(PA_8,PA_1);   // TED  Trig, Echo
HCSR04  sensorTCI(PB_1,PA_3);   // TCD  Trig, Echo
HCSR04  sensorTCD(PB_6,PA_4);   // TCI  Trig, Echo
HCSR04  sensorTED(PB_7,PA_5);   // TEI  Trig, Echo
HCSR04  sensorTLD(PB_0,PA_6);   // TLI  Trig, Echo


// CAN PARK
CAN         can_p (PA_11, PA_12, 125000);     // Rx, Tx, Frec   driver
CANMessage  msg_p;

// Distancias medidas
unsigned int distancia_TLD;
unsigned int distancia_TED;
unsigned int distancia_TCD;
unsigned int distancia_TCI;
unsigned int distancia_TEI;
unsigned int distancia_TLI;

// BACKUP's MSG CAN PARK. 
bool msg_p_0x003 = 0;

char msg_p_0x003_dato0;
char msg_p_0x003_dato0_B;

// Mensajes Tx CAN PARKING
char CAN_msg_p[8] =    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

// ESTADOS SISTEMAS
typedef enum {REPOSO, BSD, APARCAMIENTO} state_sistem;
state_sistem  state_FSM_sistem = REPOSO;



/*************************************************
    Gestion interrupciones Rx CAN PARK
**************************************************/  
void can_p_irq() {
    
    if (can_p.read(msg_p)) {

        if(msg_p.id == 0x003){            
            if(msg_p.data[0] == 0)  state_FSM_sistem = REPOSO;
            if(msg_p.data[0] == 1)  state_FSM_sistem = BSD;
            if(msg_p.data[0] == 2)  state_FSM_sistem = APARCAMIENTO;
        }
    }
}
/*************************************************/  



/************************************************
    Bucle Principal. MAIN
*************************************************/    
int main()
{        

    led=0;
    
    can_p.filter(0x003, 0x7FF, CANStandard, 0);   
    can_p.attach(callback(&can_p_irq), CAN::RxIrq); // Habilitar irq`s Rx CAN PARK.
           
           
    while(1) {

        switch (state_FSM_sistem) {
                
            case BSD:           // Sensores modo BSD.
                                
                sensorTLI.start();    // (uS/58)   max.40ms = 686cm
                sensorTLD.start();
                wait_ms(100);
  
                distancia_TLI = sensorTLI.get_dist_cm();
                if (distancia_TLI < 500) 
                    CAN_msg_p[0] = int(distancia_TLI/2);
                else 
                    CAN_msg_p[0] = 255;
                                
                distancia_TLD = sensorTLD.get_dist_cm();
                if (distancia_TLD < 500) 
                    CAN_msg_p[5] = int(distancia_TLD/2);
                else 
                    CAN_msg_p[5] = 255;
                
                                
                CAN_msg_p[1] = 255;
                CAN_msg_p[2] = 255;
                CAN_msg_p[3] = 255;
                CAN_msg_p[4] = 255;
                CAN_msg_p[6] = 255;
                CAN_msg_p[7] = 255;

                
                can_p.write(CANMessage(0x002, CAN_msg_p, 8));
                
            break;


            case APARCAMIENTO:  //  Sensores modo aparcamiento.
                
                sensorTLI.start();    // (uS/58)   max.40ms = 686cm
                sensorTCI.start();
                sensorTED.start();
                wait_ms(70);           // 100ms
                sensorTLD.start();
                sensorTCD.start();
                sensorTEI.start();
                wait_ms(70);           // 100ms
                
                distancia_TLI = sensorTLI.get_dist_cm();
                if (distancia_TLI < 500) 
                    CAN_msg_p[0] = int(distancia_TLI/2);
                else 
                    CAN_msg_p[0] = 255;
                
                distancia_TEI = sensorTEI.get_dist_cm();
                if (distancia_TEI < 500) 
                    CAN_msg_p[1] = int(distancia_TEI/2);
                else 
                    CAN_msg_p[1] = 255;
                
                distancia_TCI = sensorTCI.get_dist_cm();
                if (distancia_TCI < 500) 
                    CAN_msg_p[2] = int(distancia_TCI/2);
                else 
                    CAN_msg_p[2] = 255;


                distancia_TCD = sensorTCD.get_dist_cm();
                if (distancia_TCD < 500) 
                    CAN_msg_p[3] = int(distancia_TCD/2);
                else 
                    CAN_msg_p[3] = 255;

                distancia_TED = sensorTED.get_dist_cm();
                if (distancia_TED < 500) 
                    CAN_msg_p[4] = int(distancia_TED/2);
                else 
                    CAN_msg_p[4] = 255;
                
                distancia_TLD = sensorTLD.get_dist_cm();
                if (distancia_TLD < 500) 
                    CAN_msg_p[5] = int(distancia_TLD/2);
                else 
                    CAN_msg_p[5] = 255;
                
                
                CAN_msg_p[6] = 0x00;
                CAN_msg_p[7] = 0x00;
                can_p.write(CANMessage(0x002, CAN_msg_p, 8));
                
                //pc.printf(" %d  %d  %d  %d  %d  %d \n", (int)CAN_msg_p[0], (int)CAN_msg_p[1], (int)CAN_msg_p[2], (int)CAN_msg_p[3], (int)CAN_msg_p[4], (int)CAN_msg_p[5] );
                
            break;


            default:            //  Reposo.

                // NO HACER NADA
                
            break;      
        }

        wait_ms(20);        // 52ms
        led = !led;
    }
     
}
/*************************************************/